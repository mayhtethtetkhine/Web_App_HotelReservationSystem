<?php 	

session_start();
include 'connection.php';
include 'autoid.php';

if (isset($_GET['s_id'])) 
{
		$staffid = $_GET['s_id'];

		$r_id = $_GET['resid'];

		$query = "	SELECT r.*, rd.* 
					FROM reservation r, reservationdetail rd
					WHERE r.reservation_id = '$r_id'
					AND r.reservation_id = rd.reservation_id";

		$run = mysqli_query($connection, $query);
		$count = mysqli_num_rows($run);

		for ($i=0; $i < $count ; $i++) 
		{ 
			$array = mysqli_fetch_array($run);
			$guest_id = $array['guest_id'];

		}

		$query = "UPDATE reservation
					SET reservation_status = 'finished'
					WHERE reservation_id = '$r_id'
							";

					$run1 = mysqli_query($connection, $query);

					if ($run1) 
					{


						$io = auto_id('checkin','io_id','IO-',6);
						$today = date('Y-m-d'); 
						$time =  date("h:i:s");
						$insert = "INSERT into checkin 
									VALUES ('$io','$guest_id','$staffid','$today','$time','$r_id','No', null)";
						
						$run2 = mysqli_query($connection, $insert);

						
						if ($run2) 
						{
							echo "<script>window.alert('SUCCESS: Check-in complete.') </script>"; 
							echo "<script>window.location = 'checkin.php'</script>";
						}
						else
						{
							echo "error";
						}
						

						
					}

}

else
{
	echo "<script>window.alert('Please log in. ') </script>"; 
	echo "<script>window.location = 'stafflogin.php'</script>";
}

 ?>