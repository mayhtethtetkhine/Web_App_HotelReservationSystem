<?php 
session_start();
include 'autoid.php';
include 'connection.php';
include 'header2.php';


if (isset($_POST['btnsubmit'])) 
{	
	$rid = $_POST['txtrid'];
	$rdid = $_POST['txtrdid'];

	$in=date('Y-m-d',strtotime($_POST['datein']));
	$out=date('Y-m-d',strtotime($_POST['dateout']));

	$room = $_POST['txtroom'];
	$g = $_POST['cboguestname']; 
	$rstatus ="active";
	$date = $_POST['txtdate'];
	$_SESSION['reservationid'] = $rid; 
	$insert = "INSERT INTO reservation (reservation_id, reservation_status, reservation_date, guest_id, checkindate, checkoutdate ) VALUES ('$rid','$rstatus',  '$date', '$g', '$in', '$out')";
	$runinsert = mysqli_query($connection, $insert);
	if ($runinsert) 
	{

		$insert2 = "INSERT INTO reservationdetail (r_detail_id,reservation_id, room_id ) VALUES ('$rdid','$rid', '$room')";
		$runinsert2 = mysqli_query($connection, $insert2);
		if ($runinsert2) 
		{
			echo "<script>window.alert('Reservation complete.')</script>";
			echo "<script>window.location='dashboard.php'</script>";
		}
		else
		{
		echo mysqli_error($connection);
		echo "<script>window.location='dashboard.php'</script>";
		}
		
	}
	else
	{
		echo mysqli_error($connection);
		echo "<script>window.location='dashboard.php'</script>";
	}

		


	//rd details

	



}


 ?>





<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="datepicker.js"></script>
<link href="datecss/datepicker.css" rel="stylesheet" type="text/css">

	<title> Reservation Form </title>

<style type="text/css">

body
	{
		background-color: #768496 ;
		color: black;
	}

table
{
	border: 1px solid black;
	border-collapse: collapse;
	padding: 10px;
	width: 80%;
}

table th
{
	border: 1px solid black;
	border-collapse: collapse;
	padding-top: 40px;
	background-color: #D1D5DA;
	color: black;
	font-size: 30px;

}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: white;
}
a
{
	text-decoration: none;

}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
	float: right;

}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	margin-right: 10px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
	float: right;
}

</style> 

</head>
<body >
	<br>
<form action="reservation.php" method="post">
	<table align="center" width="80%" border="1"> 
		<tr>
			<th colspan="4" height="100px"> <h1> Reservation </h1> </th>
		</tr>
		<tr>
			<td> Reservation ID</td>
			<td><input type="text" name="txtrid" readonly="" value="<?php echo auto_id('reservation','reservation_id','RV-',6) ?>"></td>
			<td> RD ID</td>
			<td><input type="text" name="txtrdid" readonly="" value="<?php echo auto_id('reservationdetail','r_detail_id','RD-',6) ?>"></td>
		</tr>


		<tr >
			<td colspan="2" align="right" > Guest Name </td>
			<td colspan="2"> 
				<select name = "cboguestname" required="" >
					<?php 

					$selectname= "SELECT guest_id, guest_name FROM guest where guest_status = 'active' ";
					$run = mysqli_query($connection, $selectname);
					$count = mysqli_num_rows($run);
					

					for ($i=0; $i < $count ; $i++) 
					{ 
						$arr = mysqli_fetch_array($run);
						$id = $arr['guest_id'];
						$name = $arr['guest_name'];
						echo "<option value = $id> $id : $name </option> ";
					}

					 ?>


				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2" align="right" > Reservation date </td>
			<td colspan="2"> <input type="text" name="txtdate" readonly="" value=" <?php echo date('Y-m-d'); ?>"></td>
		</tr>
				
		<tr>
			<td colspan="2" align="right"> Room </td>
			<td colspan="2"> 
				<?php 

				if (isset($_GET['roomid'])) 
				{
					$rid = $_GET['roomid'];
					$select = "SELECT r.*, rt.* FROM room r, roomtype rt 
					WHERE r.room_id = $rid
					AND r.roomtype_id = rt.roomtype_id";
					$run = mysqli_query($connection, $select);
					$array = mysqli_fetch_array($run);

					$_SESSION['roomid'] = $array['room_id'];

				}
				
				?>

				 <input type="text" name="txtroom" required readonly="" value="<?php 
				 echo $array['room_id']; ?>">

			</td>
			
		</tr>
	
 		
 		<tr>
			<td> Expected Check in date </td>
			<td> <input type="text" name="datein" required="" onClick="showCalender(calender,this)" placeholder="Select Check-in date" ></td>
		
			<td> Expected Check out date </td>
			<td> <input type="text" name="dateout" required="" onClick="showCalender(calender,this)"  placeholder="Select Check-out date" ></td>
		</tr>
		
		
		<tr>
			<td colspan="4"> 
				
				<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back </a>
				
				<input type="submit" name="btnsubmit" value="Submit" id="submit"> 
				<input type="reset" value="Cancel" id="cancel" >
				
			</td>
		</tr>

 	</table>
 	</form>

</body>
</html>