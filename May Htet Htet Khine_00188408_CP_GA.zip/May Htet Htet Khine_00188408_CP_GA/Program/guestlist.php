<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	$select = "SELECT * FROM guest";
	$runselect = mysqli_query($connection, $select);
	$count = mysqli_num_rows($runselect);

	//STAFFID SESSION

	$id = $_SESSION['s_id'];
	
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 
	{
		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];
	}

}	
else
{
	echo "<script>window.alert('ERROR: Please Log in first.') </script>"; 
	echo "<script>window.location = 'stafflogin.php'</script>";
}


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 	<style type="text/css">

body
{
	background-color: #768496;
}

a
{
	text-decoration: none;
}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#add

{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #ffad87;
}
table th
{
	background-color: #D1D5DA;
}



	</style>


	<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>
 </head>
 <body>
 	<h1 style="color: white;"> GUEST LIST </h1>

 		<table id="tableid" class="display" border="1px" >
 			<thead>

 			<!-- <tr>
 				<th colspan="7"><h1> Guest List </h1></th>
 			</tr> -->
 		<tr>
 			<th> Guest ID </th>
 			<th> Name </th>
 			<th> Status </th>
 			<th> Registered by </th>
 			<th colspan="3"> Actions </th>
 		</tr>
 		</thead>

 		<tbody>

 			<?php 
 			if ($count>0) 
 			{
 				

			for ($i=0; $i < $count ; $i++) 
			{ 
				$array=mysqli_fetch_array($runselect);

				//guest session 

				$id=$array['guest_id'];
				$name=$array['guest_name'];
				$status = $array['guest_status'];
				$sid = $array['staff_id'];

				$selectstaff = "SELECT s.*              
                                FROM staff s, guest g                             
                                WHERE s.staff_id = g.staff_id
                                AND s.staff_id= '$sid' ";

            	$runselectstaff = mysqli_query($connection, $selectstaff);
           		$countstaff = mysqli_num_rows($runselectstaff);
           		$arr = mysqli_fetch_array($runselectstaff);

           		if ($countstaff > 0) 
           		{
           			$staff_name = $arr['staff_name'];
           			$sid = $arr['staff_id'];

           		}

				echo "<tr align=center> ";
				echo " <td> $id </td> ";
				echo " <td> $name </td> ";
				echo " <td> $status </td> ";
				echo " <td> $staff_name (S_ID: $sid)  </td> ";
				echo " <td > <a href= guestprofile.php?guest_id=$id > Profile </a>  </td> ";
				echo "  <td> <a href= guestdelete.php?guest_id=$id > Delete </a> </td> ";

				if ($status == 'active') 
				 {
					echo " <td> <a href= roomcheck.php > Check Room </a> </td> </tr> ";
				 }
				 else
				 {
				 	echo " <td>-</td> </tr> ";
				 }

				

			}

 			}
 			else
 			{
 				echo" <tr> <td colspan =7 align=center> <h2> No guest data found.  </h2> </td> </tr>";
 			}

		?>

</tbody>
 		</table>
<br>
 	<a href="dashboard.php" id="back"> &#8592; Back </a>
 	<a href="guest.php" id="add" style="float: right;"> &#43; Add Guest  </a>

<br> <br>

 </body>
 </html>