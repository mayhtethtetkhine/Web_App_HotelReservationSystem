<?php 
session_start();
include 'connection.php';

if (isset($_GET['st_id'])) 
{
	$id = $_GET['st_id'];
	$select = "SELECT * FROM staff WHERE staff_id = '$id' ";
	$run = mysqli_query($connection, $select);
	$count = mysqli_num_rows($run);
	for ($i=0; $i < $count ; $i++) 
	{ 
		$array = mysqli_fetch_array($run);
	}
	


}

if (isset($_POST['btnupdate'])) 
{
	$id = $_POST['sid'];
	$sname = $_POST['txtname'];
	$sposition = $_POST['txtposition'];
	$semail = $_POST['txtemail'];
	$sphone = $_POST['txtphone'];

	$insert = "UPDATE staff SET staff_name = '$sname', staff_position = '$sposition', staff_email = '$semail', staff_phone = '$sphone' WHERE staff_id = '$id'";

	$run = mysqli_query($connection, $insert);
	if ($run) 
	{
		echo "<script> window.alert('SUCCESS: Staff data updated. ')</script>";
		echo "<script> window.location='stafflist.php' </script>";
	}


}


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title> Update Staff </title>


<style type="text/css">
	
body
{
	background-color: #768496;
}
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #D1D5DA;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: white;
	width: 50%;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}


</style> 

 </head>
 <body>
 	<?php 

 	$sid = $array['staff_id'];
 	$name = $array['staff_name'];
 	$position = $array['staff_position'];
 	$email = $array['staff_email'];
 	$phone = $array['staff_phone'];

 	 ?>
 	 
 <form action="staffupdate.php" method="post">
 	<table align="center" width="80%"> 
 		<tr>
 			<th colspan="2">
 				<h1> Update Staff Data </h1>
 			</th>
 		</tr>
 		
 				<input type="text" name="sid" hidden="" value="<?php echo $sid ?>">

 		<tr>
 			<td> Name </td>
 			<td> <input type="text" name="txtname" value="<?php echo $name ?>"></td>
 		</tr>
 		<tr>
 			<td> Email </td>
 			<td> <input type="email" name="txtemail" value="<?php echo $email ?>"></td>
 		</tr>
 		<tr>
 			<td> Position </td>
 			<td> 

 				<select value = "<?php echo $position ?>" name="txtposition">
 					<option value="Data Analyst"> Data Analyst</option>
 					<option value="Receptionist"> Receptionist </option>

 				</select>

<!--  				<input type="text" name="txtposition" value="">
 --> 			</td>
 		</tr>
 		<tr>
 			<td> Phone </td>
 			<td> <input type="text" name="txtphone" value="<?php echo $phone ?>"></td>
 		</tr>

 		<tr>
 			<td colspan="2"> 
 				<br>
 				<a href="stafflist.php" id="back"> &#8592;  Back </a> 
 				<input type="submit" name="btnupdate" value="Update" id="submit" style="float: right;">
 			</td>
 		</tr>

 	</table>
 </form>

 </body>
 </html>