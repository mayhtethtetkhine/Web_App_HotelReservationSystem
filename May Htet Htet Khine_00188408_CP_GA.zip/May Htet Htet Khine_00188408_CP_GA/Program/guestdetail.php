<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	$id = $_GET['guest_id'];
	$guestselect = "SELECT * FROM guest WHERE guest_id = '$id'";
	$selectrun = mysqli_query($connection, $guestselect);
	$count = mysqli_num_rows($selectrun);
	$g_array = mysqli_fetch_array($selectrun);

	if ($count<1) 
	{
		echo "<script> window.alert('Error: Guest data not found. ')</script>";
		echo "<script> window.location='guestlist.php' </script>";
	}

	//staff session
	$id = $_SESSION['s_id'];
	
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 
	{
		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];
	}

}

else
{
	echo "<script> window.alert('Error: Please log in. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";
}





 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1> Guest Details </h1>

	<form action="guestdetil.php" method="post">
		<?php 
		$gid = $g_array['guest_id']; 
		$name = $g_array['guest_name']; 
		$nrc = $g_array['guest_nrc']; 
		$phone = $g_array['guest_phone']; 
		$sid = $g_array['staff_id']; 

		 ?>
		<table align="center">
			<tr>
				<td> Guest ID: </td>
				<td> <?php echo $gid; ?> </td>
			</tr>
			<tr>
				<td> Guest Name: </td>
				<td> <?php echo $name; ?></td>
			</tr>
			<tr>
				<td> NRC: </td>
				<td> <?php echo $nrc; ?></td>
			</tr>
			<tr>
				<td> Phone Number</td>
				<td> <?php echo $phone; ?></td>
			</tr>
			<tr>
				<td> Registered by </td>
				<td><?php echo  "Staff of ID: $sid" ; ?></td>
			</tr>
		</table>

	</form>
</body>
</html>