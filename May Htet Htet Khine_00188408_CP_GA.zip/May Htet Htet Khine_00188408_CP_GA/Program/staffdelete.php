<?php

	include ('connection.php');

	$id= $_GET['st_id'];
	$delete = "DELETE FROM staff WHERE staff_id = '$id'";
	$rundelete = mysqli_query($connection, $delete);

	if($rundelete)
	{
		echo"<script> window.alert ('SUCCESS: Staff account deleted.')</script>";
		echo"<script> window.location= 'stafflist.php'</script>";
	}
	else
	{
		echo mysqli_error($connection);
	}

?>