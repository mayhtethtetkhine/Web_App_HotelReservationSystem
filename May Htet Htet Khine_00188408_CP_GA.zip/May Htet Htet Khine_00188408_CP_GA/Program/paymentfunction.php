<?php 

//copy and ho post{} htl thwrr htae
function addroom($room_id, $price, $days)
{
	include 'connection.php';
	$select = "SELECT r.*, rd.* FROM reservation r, reservationdetail rd WHERE r.reservation_id = rd.reservation_id";
	$runselect =mysqli_query($connection, $select);
	$count = mysqli_num_rows($runselect);
	$array = mysqli_fetch_array($runselect);

	if ($count < 1) 
	{
		echo "<p> No room found. </p>";
		exit();
	}


}

 ?>