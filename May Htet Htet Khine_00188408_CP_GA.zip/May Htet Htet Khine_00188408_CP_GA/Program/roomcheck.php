<?php 

session_start();
include 'connection.php';
include 'header2.php';

if (isset($_SESSION['s_id'])) 
{
	$id = $_SESSION['s_id'];

	
if(isset($_POST['btnSearch'])) 
{
	$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType == 1) 
	{
		
		$roomid=$_POST['cboroomid'];

		$query="SELECT r.*, rt.*
				FROM room r, roomtype rt
				WHERE r.room_id='$roomid'
				AND r.roomtype_id = rt.roomtype_id
				";
		$ret=mysqli_query($connection,$query);
	}
	
	elseif($rdoSearchType == 2)
	{
		$cboStatus=$_POST['cboStatus'];

		$query="SELECT r.*, rt.*
				FROM room r, roomtype rt
				WHERE r.room_status='$cboStatus'
				AND r.roomtype_id = rt.roomtype_id
				";
		$ret=mysqli_query($connection,$query);
	}
}
else  
{
	$query="SELECT r.*, rt.*
			FROM room r, roomtype rt
			WHERE r.roomtype_id = rt.roomtype_id
			";
	$ret=mysqli_query($connection,$query);
}

if (isset($_POST['btnClear'])) 
{
	$query="SELECT r.*, rt.*
			FROM room r, roomtype rt
			WHERE r.roomtype_id = rt.roomtype_id
			";
	$ret=mysqli_query($connection,$query);
}


}
else
{
	echo "<script>window.alert('Please login first. ') </script>"; 
	echo "<script>window.location = 'stafflogin.php'</script>";
}



 ?>
<!DOCTYPE html>
<html>
<head>

	<title> Room search </title>
	<style type="text/css">

body
{
	background-color: #768496;
}		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	text-decoration: none;
	background-color: #BFC5E3;
}
table th
{
	background-color: #D1D5DA;
	border: 1px solid black;
	color: black;
}
table td
{
	background-color: white;
	border: 1px solid black;
	color: black;
}
a
{
		color: blue;
}

</style>

<script type="text/javascript" src="datejs/datepicker.js"></script>
<link rel="stylesheet" type="text/css" href="datecss/datepicker.css" />

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>

</head>
<body>
	<form action="roomcheck.php" method="post">

<table cellpadding="5px">
<tr>
	<td width="30%">
		<input type="radio" name="rdoSearchType" value="1" checked />Search by Room Number
		<br/>
		<select name="cboroomid">
			<option>--Choose Room Number--</option>
			<?php  
			$r_query="SELECT * FROM room";
			$r_ret=mysqli_query($connection,$r_query);
			$r_count=mysqli_num_rows($r_ret);

			for ($i=0;$i<$r_count;$i++) 
			{ 
				$r_arr=mysqli_fetch_array($r_ret);
				$RoomID=$r_arr['room_id'];
				echo "<option value='$RoomID'> $RoomID</option>";
			}
			?>
		</select>
	</td>
	
	<td width="30%">
		<input type="radio" name="rdoSearchType" value="2" />Search by Status
		<br/>
		<select name="cboStatus">
			<option value="Available"> Available</option>
			<option value="Out of order"> Out of order</option>
		</select>
	</td>
	<td width="35%">
		<br/>
		<input type="submit" name="btnSearch" value="Search" style="float: left; margin-right: 10px;" />
		<input type="submit" value="Show All" name="btnClear" style="float: left;" />
	</td>
</tr>
</table>
<hr/>
<?php  
$count=mysqli_num_rows($ret);

if($count < 1) 
{
	echo "<p>No Record Found.</p>";
}
else
{
?>
	<table  id="tableid" class="display" border="1px">
		<tr>
			<th>#</th>
			<th>Room ID </th>
			<th>Room Type </th>
			<th>Status</th>
			<th>Action</th>
		</tr>
		<?php 
		for($i=0;$i<$count;$i++) 
		{ 
			$row=mysqli_fetch_array($ret);
			$roomid=$row['room_id'];
			$status = $row['room_status'];
			echo "<tr>";
				echo "<td>" . ($i+1) . "</td>";
				echo "<td>". $roomid ."</td>";
				echo "<td>". $row['roomtype_name'] ."</td>";
				echo "<td>". $row['room_status'] ."</td>";
				
				if ($status == 'Available' ) 
				{
					echo "<td> 
						<a href='reservation.php?roomid=$roomid'> Reserve </a> 
					  </td>";
				}
				else
				{
					echo "<td> 
							
						<p> - </p>
						</td>";
				}
				
			echo "</tr>";
		}
		?>

	</table>


<?php
}
?>

<br><br>


<a href="dashboard.php" id="back"> &#8592; Back </a>

</form>

</body>

</html>