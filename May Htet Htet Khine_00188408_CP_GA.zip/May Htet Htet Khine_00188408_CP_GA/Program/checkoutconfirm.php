<?php 

session_start();
include 'connection.php';

if ($_GET['ioid']) 
{
	$io = $_GET['ioid'];
	$s_id = $_SESSION['s_id'];
	$_SESSION['s_id'] = $s_id;
 
 //to change before submitting program
	$date =  date('Y-m-d'); 
	//$date =  date('2021-10-12'); 


	$query = "	UPDATE checkin 
				SET check_out = 'Yes'
				WHERE io_id = '$io'";

	$run = mysqli_query($connection, $query);

	$query1 = "	UPDATE checkin 
				SET checkout_date = '$date'
				WHERE io_id = '$io'";
	$run1 = mysqli_query($connection, $query1);

	if ($run && $run1) 
	{

		echo "<script>window.alert('SUCCESS: Checked out. ') </script>"; 
		echo "<script>window.location = 'payment.php?ioid=$io' </script>";
	}
}


 ?>