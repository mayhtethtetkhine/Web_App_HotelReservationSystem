<?php 

session_start();
include 'connection.php';
include 'autoid.php';


if (isset($_SESSION['s_position'])) 
{
	$pos = $_SESSION['s_position'];
	if ($pos != 'Data Analyst') 
	{
		echo "<script>window.alert('You do not have access.')</script>";
		echo "<script>window.location='dashboard.php'</script>";
	}
}



if (isset($_POST['btnsubmit'])) 
{
	$id = $_POST['txtid'];
	$type = $_POST['txttype'];
	$price = $_POST['txtprice'];
	$clean = $_POST['rdocleaning'];
	$bed = $_POST['txtbed'];


	$checktype = "SELECT * FROM roomtype WHERE roomtype_name = '$type'";
	$runchecktype = mysqli_query($connection, $checktype);
	$count = mysqli_num_rows($runchecktype);

		if ($count>0) 
		{
			echo "<script>window.alert('ERROR: This Room type ($type) exists in database. ') </script>"; 
			echo "<script> window.location = 'roomtypes.php'</script>";
		}

		else
		{

			$check = $_POST['txtservices'];
			
			{
				$first="";
				foreach ($_POST['txtservices'] as $services) 
				{
					$first.=$services.",";
				}
				$second=rtrim($first,',');
			}
			
	

			$inserttype = "INSERT INTO roomtype (roomtype_id, roomtype_name, roomtype_price, roomtype_cleaning, roomtype_bed, roomtype_services ) VALUES ('$id', '$type', '$price', '$clean', '$bed', '$second') ";
			$runinsert = mysqli_query($connection, $inserttype);


			if ($runinsert)
			{
				echo "<script>window.alert('SUCCESS: Room Type Added.')</script>";
				echo "<script>window.location='dashboard.php'</script>";
			}

			else
			{
				echo"<p>Something went wrong in RoomType_Entry:". mysqli_error($connection)."</p>";
				echo "<script>window.location='roomtypes.php'</script>";
			}


		}


	
}



 ?>


<!DOCTYPE html>
<html>
<head>
	<title> Room Types </title>

<style type="text/css">

body
	{
		background-color: #768496 ;
	}
		
table
{
	border: 1px solid;
	border-collapse: collapse;
	
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #D1D5DA;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: white;
}
a
{
	text-decoration: none;
	padding: 7px;
	background-color: #f08080;
	color: black;

}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
	text-decoration: none;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: white;
	border: 1px solid black;
}



</style>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>

<script type="text/javascript">
$(document).ready(function () {
    $('#submit').click(function() {
      checked = $("input[type=checkbox]:checked").length;

      if(!checked) {
        alert("Please check at least one in Free Service ");
        return false;
      }

    });
});

function ckChange(el) {
  var ckName = document.getElementsByName(el.name);
  if (el.checked) {
    for (var i = 0; i < ckName.length; i++) {
      ckName[i].disabled = ckName[i] !== el;
    }
  } else {
    for (var i = 0; i < ckName.length; i++) {
      ckName[i].disabled = false
    }
  }

}



</script>

</head>
<body>

	<form action="roomtypes.php" method="post">


		<table align="center" width="80%" >
			<tr>
				<th colspan="2"><h1> Register Roomtype </h1> </th>
			</tr>
			<tr>
				<td width="50%" align="center">ID</td>
				<td><input type="text" required="" name="txtid" readonly="" value="<?php echo auto_id('roomtype','roomtype_id','RT-',6) ?>"></td>
			</tr>
			<tr>
				<td align="center" > Type Name </td>
				<td> <input type="text" name="txttype" placeholder="Enter Room type name" required autofocus=""></td>
			</tr>
			<tr>
				<td align="center" > Price </td>
				<td> <input type="number" placeholder="Enter price" name="txtprice" required></td>
			</tr>
			<tr>
				<td align="center"> Cleaning </td>
				<td> 
					<input type="radio" name="rdocleaning" value="once_a_day" selected="" > Once a day 
					<input type="radio" name="rdocleaning" value="twice_a_day" > Twice a day

				</td>
			</tr>
			
			<tr>
				<td align="center" > Number of bed</td>
				<td> <input type="number" placeholder="Number of beds" required name="txtbed" min="1" max="5" ></td>
			</tr>
			
			<tr>
				<td align="center">
					Free services
				</td>
				<td>
					<input type="checkbox" name="txtservices[]" value="None" 
					onclick= "ckChange(this)" />
					None     
					<br> 
					--------------------
					<br>
					
					<input type="checkbox" name="txtservices[]" value="Swimming Pool"/>
					Swimming Pool
					<br>
					
					<input type="checkbox" name="txtservices[]" value="Spa"/>
					Spa
					<br>

					<input type="checkbox" name="txtservices[]" value="Airport Vehical"/>
					Airport Vehical   
					<br>

					<input type="checkbox" name="txtservices[]" value="Sea View"/>
					Sea View 
					<br>

					<input type="checkbox" name="txtservices[]" value="Breakfast"/>
					Breakfast     
					<br>

					<input type="checkbox" name="txtservices[]" value="Lunch"/>
					Lunch     
					<br>

					<input type="checkbox" name="txtservices[]" value="Dinner"/>
					Dinner     
					<br> 
					
					

				</td>
			</tr>
			<tr>
				<td colspan="2" align="right">
				<br>
				<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back  </a>
				
				<input type="submit" name="btnsubmit" value="Submit" id="submit">
				<input type="reset" name="btncancel" value="Cancel" id="cancel">
				</td>
			</tr>
			
		</table>


<br>
	<table id="tableid" class="display" >

		<tr>
			<th> RT-ID </th>
			<th> Name </th>
			<th> Price </th>
			<th> Number of beds </th>
			<th> Cleaning </th>
			<th> Services </th>
			<th> Action </th>
		</tr>

<?php 

$select = "SELECT * FROM roomtype";
$run = mysqli_query($connection, $select);
$count = mysqli_num_rows($run);


for ($i=0; $i < $count ; $i++) 
{ 
	$array = mysqli_fetch_array($run);
	$id = $array['roomtype_id'];
	$name = $array['roomtype_name'];
	$price = $array ['roomtype_price'];
	$bed = $array ['roomtype_bed'];
	$cleaning = $array ['roomtype_cleaning'];
	$services = $array['roomtype_services'];

	echo "<tr align=center >";
	echo "<td> $id </td>";
	echo "<td> $name </td>";
	echo "<td> $price </td>";
	echo "<td> $bed </td>";
	echo "<td> $cleaning </td>";
	echo "<td> $services </td>";
	echo "<td> <a href= roomtypedelete.php?rtid=$id> Delete </a>";

	echo "</tr>";

}






 ?>


	</table>

	</form>
</body>
</html>