<div class="bgded overlay light" style="background-image:url('images/demo/backgrounds/01.png'); overflow-y: hidden;">
  <section id="services" class="hoc container clear"> 
    <!-- ################################################################################################ -->
    <!-- <div class="sectiontitle">
      <p class="nospace font-xs"> Menu </p>
      <h6 class="heading font-x2">Dashboard</h6>
    </div> -->
    <ul class="nospace group elements elements-three">
      <li class="one_third">
        <article><a href="guest.php"><i class="fas fa-registered" >
          <!-- fa-hourglass-half -->
        </i></a>
          <h6 class="heading">Register Guest</h6>
          <p>Register new guest coming into the hotel. </p>
        </article>
      </li>
      <li class="one_third">
        <article><a href="guestlist.php"><i class="fas fa-user-friends"></i></a>
          <h6 class="heading">Guest List </h6>
          <p> View the list of all guests registered. </p>
        </article>
      </li>
      <li class="one_third">
        <article><a href="checkin.php"><i class="fas fa-sign-in-alt"></i></a>
          <h6 class="heading"> Check in </h6>
          <p> View reservations that are to be checked in</p>
        </article>
      </li>
      <li class="one_third">
        <article><a href="roomcheck.php"><i class="far fa-list-alt"></i></a>
          <h6 class="heading"> Reserve </h6>
          <p> See which rooms can be reserved now </p>
        </article>
      </li>
      <li class="one_third">
        <article><a href="paymentlist.php"><i class="fas fa-hand-holding-usd"></i></a>
          <h6 class="heading"> Payments </h6>
          <p>See previous payment records </p>
        </article>
      </li>
      <li class="one_third">
        <article><a href="checkout.php"><i class="fas fa-user-minus"></i></a>
          <h6 class="heading"> Check out </h6>
          <p> Mark the guest as checked out</p>
        </article>
      </li>
    </ul>
    <!-- ################################################################################################ -->
  </section>
</div>