<?php

include ('connection.php');
$g_id= $_GET['guest_id'];
$delete = "DELETE FROM guest WHERE guest_id = '$g_id'";
$rundelete = mysqli_query($connection, $delete);

if($rundelete)
{
	echo"<script> window.alert ('SUCCESS: Guest data deleted.')</script>";
	echo"<script> window.location= 'guestlist.php'</script>";
}
else
{
	echo mysqli_error($connection);
}
?>