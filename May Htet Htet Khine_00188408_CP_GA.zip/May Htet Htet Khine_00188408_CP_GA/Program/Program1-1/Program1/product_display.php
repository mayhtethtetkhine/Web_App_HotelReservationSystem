<?php 
session_start();
include ($connection);


 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Display</title>
</head>
<body>
	<form action="product_display.php">
		<fieldset>
			<legend> Product display</legend>
			<table>	
				<tr>
					<td> 
						<input type="text" name="txtdata" placeholder="enter keyword">
						<input type="submit" name="btnsearch" value="search">


					</td>
				</tr>
			</table>
			<hr/>

<table>


<?php 

if (isset($_POST['btnsearch'])) 
{
	$txtdata = $_POST['txtdata'];



$query1 = "SELECT * from product WHERE ProductName LIKE '%$txtData%' 
	OR Price = '$txtdata'
	"; 
$ret1 = mysqli_query($connection,$query1);
$count1 = mysql_num_rows($ret1);


============
for ($i=0; $i < $count ; $i+=4) 
{ 
	$query2 = "SELECT * from product WHERE ProductName LIKE '%$txtData%' 
	OR Price = '$txtdata' LIMIT $i,4";
	$ret2 = mysqli_query($connection,$query2);
	$count2 = mysql_num_rows($ret2);
	echo "<tr>";
		for ($x=0; $x < $count2 ; $x++)

		{ 
			$row = mysqli_fetch_array($ret1);
		}

	echo "<tr>";
	for ($x=0; $x < $count2; $x++) 
	{ 
		$row = mysqli_fetch_array ($ret1);
		$productid = $row['ProductID'];
		$productname = $row['ProductName'];
		$price = $row['Price'];
		$productimage = $row['ProductImg1'];

		list($width,$height) = getimagesize($productimage);
		$w = $width/2.5;
		$h = $height/2.5;

		?>

		<td>
			<img src="<?php echo $productimage1 ?>" width= 100px height= 100px >
			<hr/>
			<b> <?php echo $productname ?> </b>

			<hr/>
			<a href="product_details.php?productid= <?php $prodectid ?>"> </a>
		</td>

		<?php


	}
}






}

//======

else

{


$query1 = "SELECT * from product"; 
$ret1 = mysqli_query($connection,$query1);
$count1 = mysql_num_rows($ret1);

for ($i=0; $i < $count ; $i+=4) 
{ 
	$query2 = "SELECT * from product LIMIT $i,4";
	$ret2 = mysqli_query($connection,$query2);
	$count2 = mysql_num_rows($ret2);
	echo "<tr>";
		for ($x=0; $x < $count2 ; $x++)

		{ 
			$row = mysqli_fetch_array($ret1);
		}

	echo "<tr>";
	for ($x=0; $x < $count2; $x++) 
	{ 
		$row = mysqli_fetch_array ($ret1);
		$productid = $row['ProductID'];
		$productname = $row['ProductName'];
		$price = $row['Price'];
		$productimage = $row['ProductImg1'];

		list($width,$height) = getimagesize($productimage);
		$w = $width/2.5;
		$h = $height/2.5;

		?>

		<td>
			<img src="<?php echo $productimage1 ?>" width= 100px height= 100px >
			<hr/>
			<b> <?php echo $productname ?> </b>

			<hr/>
			<a href="product_details.php?productid= <?php $prodectid ?>"> </a>
		</td>

		<?php


	}
}

}





 ?>

</table>


		</fieldset>



	</form>
</body>
</html>