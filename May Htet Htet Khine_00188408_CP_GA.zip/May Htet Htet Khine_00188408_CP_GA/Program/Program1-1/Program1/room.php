<?php 

session_start();
include 'connection.php';


if (isset($_POST['btnsubmit'])) 

{
	$id= $_POST['txtid'];
	$status = $_POST['cbostatus'];
	$typeid = $_POST['cbotype'];
	$img1 = $_FILES['fileroomimg1']['name'];
	$img2 = $_FILES['fileroomimg2']['name'];
	$folder = "roomimg/";


	if ($img1) 
	{
		$filename1= $folder."_".$img1;
		$copy1 = copy($_FILES['fileroomimg1']['tmp_name'], $filename1);
		if (!$copy1) 
		{
				exit("ERROR: Image cannot be uploaded. Try again.");
		}

	}
	if ($img2) 
	{
		$filename2= $folder."_".$img2;
		$copy2 = copy($_FILES['fileroomimg2']['tmp_name'], $filename2);
		if (!$copy2) 
		{
				exit("ERROR: Image cannot be uploaded. Try again.");
		}

	}


		$checkroom = "SELECT * FROM room WHERE room_id = '$id'";
		$runcheckroom = mysqli_query($connection, $checkroom);
		$count = mysqli_num_rows($runcheckroom);

		if ($count>0) 
		{
			echo "<script>window.alert('ERROR: Room number exists in Database. Try another room number. ') </script>"; 
			echo "<script>window.location = 'room.php'</script>";
		}
		else
		{
			$insertroom = "INSERT INTO room (room_id, room_status, room_img, room_img2, roomtype_id ) VALUES ('$id','$status','$filename1', '$filename2','$typeid')";
			$runinsert = mysqli_query($connection, $insertroom);

			if ($runinsert)
			{
				echo "<script>window.alert('SUCCESS: Room added.')</script>";
				echo "<script>window.location='dashboard.php'</script>";
			}
			else
			{
				echo mysqli_error($connection);
				echo "<script>window.location='room.php'</script>";
			}


		}


}

 ?>



<!DOCTYPE html>
<html>
<head>
	<title> Room Entry </title>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
<!-- 	<style type="text/css">
		
		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}


#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	text-decoration: none;
	background-color: #BFC5E3;
}


#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}
a
{
	text-decoration: none;
}



	</style> -->
</head>
<body>
<form action="room.php"  method="post" enctype="multipart/form-data">
	

	<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


	</script>
	
<table> 
	
	<tr>
		<th colspan="2"><h1> Add Room </h1></th>
	</tr>
	<tr>
		<td>Room Number</td>
		<td> <input type="text" name="txtid" required=""></td>
	</tr>
	<tr>
		<td>Room Status</td>
		<td>
			<select name="cbostatus">
				<option value="available"> Available </option>
				<option value="outoforder"> Out of Order </option>
			</select>

		</td>
	</tr>
	<tr>
		<td> Room Image 1 </td>
		<td>
			<input type="file" name="fileroomimg1">
		</td>
	</tr>
	<tr>
		<td> Room Image 2 </td>
		<td>
			<input type="file" name="fileroomimg2">
		</td>
	</tr>
	<tr>
		<td> Room Type </td>
		<td>
			<select name="cbotype">
				
				<?php 

				$selecttype = "SELECT * FROM roomtype";
				$selecttyperun = mysqli_query($connection, $selecttype);
				$counttype = mysqli_num_rows($selecttyperun);
				for ($i=0; $i < $counttype ; $i++) 
				{ 
					$array = mysqli_fetch_array($selecttyperun);
					$id = $array['roomtype_id'];
					$type = $array['roomtype_name'];
					echo "<option value='$id'> $id </option>";
				}

				 ?>

			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="right"> 
			<br>
			<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back </a>
			
			<input type="submit" name="btnsubmit" value="Submit" id="submit">
			<input type="reset" name="btncancel" value="Cancel" id="cancel">
		</td>
	</tr>

</table>

</form>

<hr/>
<br>
	<table id="tableid" class="display">
		<thead>
		<tr align="center">
			<th> Room No. </th>
			<th> Room Type </th>
			<th> Status </th>
			<th> Image 1 </th>
			<th> Image 2 </th>
			<th> Action </th>
		</tr>
		</thead>
		<tbody>

			<?php 

			$select = "	SELECT r.*, rt.* FROM room r, roomtype rt
						WHERE r.roomtype_id = rt.roomtype_id ";
			$runselect = mysqli_query($connection, $select);
			$count = mysqli_num_rows($runselect);
			echo "$count";
			
			if ($count>0) 
			{
			
			for ($i=0; $i < $count ; $i++) 
				{ 
				
					$array = mysqli_fetch_array($runselect);
				//-----
					$num = $array['room_id'];
					$type = $array['roomtype_id'];
					
					// $select_typeid = "SELECT roomtype_name FROM roomtype WHERE roomtype_id = '$typeselect' ";
					// $count_typeid = mysqli_num_rows ($select_typeid);
					// $run = mysqli_query($connection, $select);

					// $typearray = mysqli_fetch_array($run); 
					// for ($i=0; $i < $count_typeid ; $i++) 
					// { 
					// 	$typeid = $typearray[];
					// }

					$status = $array['room_status'];
					$img1 = $array['room_img'];
					$img2 = $array['room_img2'];

					echo "<tr align=center>";
					echo "<td> $num </td>";
					echo "<td> $type </td>";
					echo "<td> $status </td>";
					echo "<td> <img src= $img1 height = 100px width=100px> </td>";
					echo "<td> <img src= $img2 height = 100px width=100px> </td>";
					echo"<td> <a href= roomupdate.php?number=$num > Update </a> <br>
					<a href = roomdelete.php?number=$num> Delete </a> 

					</td>";
					echo "</tr>";
				}
			}
			else
			{
				echo "<tr align=center >";
				echo "<td colspan = 5> <h3> No Data </h3> ";
				echo "<tr>";
			}


			 ?>

			 </tbody>
	</table>



</body>
</html>
