<?php 

session_start();
include 'connection.php';
include 'autoid.php';

if (isset($_SESSION['s_id'])) 
{
	
	$id = $_SESSION['s_id'];

	if (isset($_POST['btnadd'])) 
	{
		$gid = $_POST['txtid'];
		$name= $_POST['txtname'];
		$nrc = $_POST['txtnrc'];
		$phone = $_POST['txtphone']; 
		$status = "active"; 
		$sid = $id;

		$checknrc = "SELECT * FROM guest WHERE guest_nrc = '$nrc'";
		$runchecknrc = mysqli_query($connection, $checknrc);
		$count = mysqli_num_rows($runchecknrc);

			if ($count>0) 
			{
				echo "<script>window.alert('ERROR: This NRC exists in the database. ') </script>"; 
				echo "<script>window.location = 'guest.php'</script>";
			}

			else
			{
				$insertguest = "INSERT INTO guest (guest_id, guest_name , guest_nrc , guest_phone, guest_status, staff_id ) VALUES ('$gid','$name', '$nrc' , '$phone' ,'$status', '$sid')";

				$runinsert = mysqli_query($connection, $insertguest);

				if ($runinsert)
				{
					echo "<script>window.alert('SUCCESS: Guest profile recorded.')</script>";
					echo "<script>window.location='guestlist.php'</script>";
				}

				else
				{
					echo mysqli_error($connection);
					echo "<script>window.location='staffregister.php'</script>";
				}
			}

	}

	$id = $_SESSION['s_id'];
	$name= $_SESSION['s_name'];
	$position = $_SESSION['s_position'];
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 

	{

	$_SESSION['s_id'] = $array['staff_id'];
	$_SESSION['s_name'] = $array['staff_name'];
	$_SESSION['s_position'] = $array['staff_position'];

	}
}

else
{
	echo "<script> window.alert('Error: Please log in again. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";
}


 ?>


<!DOCTYPE html>
<html>
<head>
	<title> Add Guest </title>
	<!-- <style type="text/css">

		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}
#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}





</style>
 -->

</head>
<body>

<form action="guest.php" method="post">
<table ><!-- align="center" width="100%" -->
	<tr>
		<th colspan="2"><h1> Add Guest </h1> </th>
	</tr>
	<tr> 
		<td> ID </td>
		<td><input type="text" name="txtid" readonly="" value="<?php echo auto_id('guest','guest_id','GT-',6) ?>"></td>
	</tr>
	<tr> 
		<td> Name </td>
		<td><input type="text" name="txtname" autofocus=""></td>
	</tr>
	<tr> 
		<td> NRC </td>
		<td> <input type="text" name="txtnrc"></td>
	</tr>
	<tr>
		<td> Phone </td>
		<td> <input type="text" name="txtphone"></td>
	</tr>
	<tr>
		<td colspan="2" align="right">
			<br>	
		<a href="dashboard.php" id="back" style="float: left"> &#8592; Back </a>
		<input type="submit" name="btnadd" value="Add" id="submit">
		<input type="reset" name="btncancel" value="Cancel" id="cancel">
		</td>
	</tr>
	
</table>
</form>



</body>
</html>