<?php 
session_start();
include 'autoid.php';
include 'connection.php';

if (isset($_SESSION['reservationid']) AND isset($_SESSION['roomid'])  )
{
	$reserveid= $_SESSION['reservationid'];
	$select = "SELECT r.*, rv.* FROM room r, reservation rv WHERE reservation_id = '$reserveid'";
	$run = mysqli_query($connection, $select);
	$array = mysqli_fetch_array($run);

	if (isset($_POST['btnsubmit'])) 
	{
		$rdid = $_POST['txtrdid'];
		$resid = $_POST['txtresid'];
		$datein = $_POST['datein'];
		$dateout = $_POST['dateout'];
		$room = $_POST['txtroomid'];

		$insert = "INSERT INTO reservationdetail (r_detail_id, checkin_date, checkout_date,reservation_id, room_id) VALUES ('$rdid', '$datein', '$dateout', '$resid', '$room')";
		$run = mysqli_query($connection, $insert);
		if ($run) 
		{

			echo "<script> window.alert('SUCCESS: Reservation recorded.') date_diff($datein, $dateout) </script>";
			echo "<script> window.location = 'roomcheck.php' </script>";
		}
		else
		{
			echo "<script> window.alert('ERROR submit') </script>";
		}

	}

}
else
{
	echo "<script> window.alert('ERROR') </script>";
}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>
 		Reservation Details
 	</title>

<script type="text/javascript" src="datepicker.js"></script>
<link href="datecss/datepicker.css" rel="stylesheet" type="text/css">


<style type="text/css">

table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}

</style>


 </head>
 <body>
 	<?php 

 	$resid = $array['reservation_id'];
 	$roomid = $array['room_id']; 

 	 ?>
 	 <form action="reservationdetail.php" method="post">
 	<table width="100%">
 		
 		<tr>
 			<th colspan="2"> <h1> Details </h1> </th>
 		</tr>
 		<tr>
 			<td> Details ID </td>
 			<td> <input type="text" name="txtrdid" readonly="" value="<?php echo auto_id('reservationdetail','r_detail_id','RD-',6) ?>"></td>
 		</tr>
 		<tr>
 			<td> Reservation ID </td>
 			<td> <input type="text" name="txtresid" readonly="" value=" <?php echo "$resid"; ?>"></td>
 		</tr>
 		<tr>
			<td> Check in date </td>
			<td> <input type="text" name="datein" onClick="showCalender(calender,this)" placeholder="Select Check-in date" ></td>
		</tr>
		<tr>
			<td> Check out date </td>
			<td> <input type="text" name="dateout" onClick="showCalender(calender,this)"  placeholder="Select Check-out date" ></td>
		</tr>
		<tr>
			<td> Room ID </td>
			<td> <input type="text" name="txtroomid" readonly="" value=" <?php echo $roomid ?> "></td>
			
		</tr>
		<tr>
			<td colspan="2" align="right">
				<input type="submit" id="submit" name="btnsubmit" value="Save">
				<input type="reset" id="cancel" value="Cancel">
			 </td>
		</tr>

 	</table>
 	</form>
 </body>
 </html>