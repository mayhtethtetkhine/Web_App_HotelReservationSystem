<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	
	$id = $_SESSION['s_id'];
	$name= $_SESSION['s_name'];
	$position = $_SESSION['s_position'];
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 
	{
		echo "<h1> Welcome, $name , our $position . </h1>";

		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];

		$Today=date('Y-m-d');
		$select = "SELECT r.*, rd.*, g.* FROM reservation r, reservationdetail rd, guest g
					WHERE r.guest_id = g.guest_id AND r.reservation_status='active'
					AND rd.checkin_date > '$Today';
					 ";

		$run = mysqli_query($connection, $select);
		//$count = mysqli_num_rows($run);

	}

	else
	{
		echo "<script> window.alert('Error: Please log in again. ')</script>";
		echo "<script> window.location='stafflogin.php' </script>";
	}



}


 ?>

<!--
 r.reservation_status='active' AND
					AND rd.guest_id = g.guest_id  -->

<!DOCTYPE html>
<html>
<head>
	<title> Dashboard </title>
</head>
<body>

<a href="staffregister.php"> Register staff </a><br>
<a href="roomtypes.php"> Add room type </a> <br>
<a href="room.php"> Add room </a> <br>
<a href="stafflist.php"> staff list </a> <br>
<a href="guestlist.php"> view guests </a> <br>
<a href="guest.php"> add guest </a> <br>
<a href="roomcheck.php"> Available Rooms </a> <br>
<a href="stafflogout.php"> Log out </a>
<a href="checkin.php"> Check In </a>

<!-- 
<table border="1">
	<tr>
		<th colspan="7"> <h1> Active Reservations </h1></th>
	</tr>
	<tr>
		<td> Reservation ID </td>
		<td> Reservation Date</td>
		<td> Room </td>
		<td> Guest ID </td>
		<td> Guest Name </td>
		<td> Check in Date </td>
		<td> Check out Date </td>
	</tr>
	<?php 
	echo "$count";
	for ($i=0; $i < $count ; $i++) 
	{ 

		$r_array = mysqli_fetch_array($run);

		$resid = $r_array['reservation_id'];
		$rdate = $r_array['reservation_date'];
		$room = $r_array['room_id'];
		$guestid = $r_array['guest_id'];
		$guestname = $r_array['guest_name'];
		$datein = $r_array['checkin_date'];
		$dateout = $r_array['checkout_date'];

		echo "<tr>";

		echo "<td> $resid </td> ";
		echo "<td> $rdate </td> ";
		echo "<td> $room </td> ";
		echo "<td> $guestid </td> ";
		echo "<td> $guestname </td> ";
		echo "<td> $datein </td> ";
		echo "<td> $dateout </td> ";

		echo "</tr>";

	}







	 ?>
</table>

 -->


</body>
</html>