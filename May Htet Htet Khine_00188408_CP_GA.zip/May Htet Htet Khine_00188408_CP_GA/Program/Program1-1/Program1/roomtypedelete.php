<?php

include ('connection.php');
$rtid= $_GET['rtid'];
$delete = "DELETE FROM roomtype WHERE roomtype_id = '$rtid'";
$rundelete = mysqli_query($connection, $delete);

if($rundelete)
{
	echo"<script> window.alert ('SUCCESS: Roomtype deleted.')</script>";
	echo"<script> window.location= 'roomtypes.php'</script>";
}
else
{
	echo mysqli_error($connection);
}
?>