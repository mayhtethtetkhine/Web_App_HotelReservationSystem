-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2021 at 11:17 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkin`
--

CREATE TABLE `checkin` (
  `io_id` varchar(10) NOT NULL,
  `guest_id` varchar(10) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `checkin_date` date NOT NULL,
  `reservation_id` varchar(10) DEFAULT NULL,
  `check_out` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_id` varchar(15) NOT NULL,
  `guest_name` varchar(50) NOT NULL,
  `guest_nrc` varchar(50) NOT NULL,
  `guest_phone` varchar(50) NOT NULL,
  `guest_status` varchar(30) NOT NULL,
  `staff_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `guest_name`, `guest_nrc`, `guest_phone`, `guest_status`, `staff_id`) VALUES
('GT-000001', 'jkjdjf', '12121', '099999', 'active', 6),
('GT_000002', 'aye aye', '345353', '3453534', 'active', 6);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` varchar(15) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` int(11) NOT NULL,
  `tax` float NOT NULL,
  `staff_id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` varchar(15) NOT NULL,
  `reservation_status` varchar(50) NOT NULL,
  `reservation_date` varchar(20) NOT NULL,
  `guest_id` varchar(15) NOT NULL,
  `checkindate` varchar(33) NOT NULL,
  `checkoutdate` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `reservation_status`, `reservation_date`, `guest_id`, `checkindate`, `checkoutdate`) VALUES
('RV-000001', 'Received', ' 2021-09-24', 'GT-000001', '26-Sep-2021', '27-Sep-2021');

-- --------------------------------------------------------

--
-- Table structure for table `reservationdetail`
--

CREATE TABLE `reservationdetail` (
  `reservation_id` varchar(15) NOT NULL,
  `room_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservationdetail`
--

INSERT INTO `reservationdetail` (`reservation_id`, `room_id`) VALUES
('RV-000001', '55');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` varchar(10) NOT NULL,
  `room_status` varchar(30) NOT NULL,
  `room_img` text NOT NULL,
  `room_img2` text NOT NULL,
  `roomtype_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_status`, `room_img`, `room_img2`, `roomtype_id`) VALUES
('55', 'available', 'roomimg/_pakistan.png', 'roomimg/_sk.png', 'RT-000001');

-- --------------------------------------------------------

--
-- Table structure for table `roomtype`
--

CREATE TABLE `roomtype` (
  `roomtype_id` varchar(15) NOT NULL,
  `roomtype_name` varchar(30) NOT NULL,
  `roomtype_price` int(11) NOT NULL,
  `roomtype_cleaning` varchar(30) NOT NULL,
  `roomtype_bed` int(11) NOT NULL,
  `roomtype_services` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roomtype`
--

INSERT INTO `roomtype` (`roomtype_id`, `roomtype_name`, `roomtype_price`, `roomtype_cleaning`, `roomtype_bed`, `roomtype_services`) VALUES
('RT-000001', 'Standard Single', 100, 'once_a_day', 1, 'Swimming Pool,Breakfast'),
('RT-000002', 'Big room', 2323, 'twice_a_day', 2, 'Swimming Pool,Sea View');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` int(11) NOT NULL,
  `staff_name` varchar(50) NOT NULL,
  `staff_email` varchar(60) NOT NULL,
  `staff_password` varchar(50) NOT NULL,
  `staff_phone` varchar(50) NOT NULL,
  `staff_position` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `staff_email`, `staff_password`, `staff_phone`, `staff_position`) VALUES
(1, 'Ma Mo', 'ma@gmail.com', 'ma', '09888000', 'Data Analyst'),
(5, 'staffff', 'staff@gmail.com', 'staff', '099999', 'Data Analyst'),
(6, 'ssss', 'dd@gmail.com', 'aaa', '08777', 'Data Analyst');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `roomtype`
--
ALTER TABLE `roomtype`
  ADD PRIMARY KEY (`roomtype_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
