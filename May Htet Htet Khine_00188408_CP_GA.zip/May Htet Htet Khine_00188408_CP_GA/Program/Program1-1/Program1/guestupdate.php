
<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['g_id'])) 
{
	$id = $_SESSION['g_id'];

	$guestselect = "SELECT * FROM guest WHERE guest_id = '$id'";
	$selectrun = mysqli_query($connection, $guestselect);
	$count = mysqli_num_rows($selectrun);
	$g_array = mysqli_fetch_array($selectrun);

	if ($count<1) 
	{
		echo "<script> window.alert('Error: Guest data not found. ')</script>";
		echo "<script> window.location='guestlist.php' </script>";
	}


	if (isset($_POST['btnupdate'])) 
	{
		$name = $_POST['txtname'];
		$nrc = $_POST['txtnrc'];
		$phone = $_POST['txtphone'];
		$status = $_POST['rdostatus'];

		$update = "UPDATE guest SET guest_name = '$name', guest_nrc= '$nrc', guest_phone='$phone' , guest_status = '$status' WHERE guest_id ='$id' ";
		$runupdate = mysqli_query($connection, $update); 

		if ($runupdate) 
		{
			echo "<script> window.alert('SUCCESS: Guest profile updated. ')</script>";
			echo "<script>window.location='guestlist.php'</script>";
		}
		else
		{
			echo mysqli_error($connection) ;
			echo "<script>window.location='guestlist.php'</script>";
		}



	}

	
}


 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
<!-- <style type="text/css">

		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}

</style> -->
</head>
<body>



<?php 

$id = $g_array['guest_id'];
$name = $g_array['guest_name'];
$nrc = $g_array['guest_nrc'];
$phone = $g_array['guest_phone'];
$status = $g_array['guest_status'];
$s_id = $g_array['staff_id'];


 ?>


<form action="guestupdate.php" method="post">
<table> <!-- align="center" width="100%"> -->
	<tr>
		<th colspan="2"> <h1> Guest Update Profile</h1> </th>
	</tr>
	<tr>
		<td> Guest ID: </td>
		<td> <?php echo "$id"; ?> </td>
	</tr>

	<tr>
		<td> Name </td>
		<td>  <input type="text" name="txtname" value= "<?php echo $name ; ?>" ></td>
	</tr>

	<tr>
		<td> NRC </td>
		<td> <input type="text" name="txtnrc" value=<?php echo "$nrc"; ?>></td>
	</tr>

	<tr>
		<td> Phone </td>
		<td> <input type="text" name="txtphone" value=<?php echo "$phone"; ?>></td>
	</tr>
	<tr>
		<td> Status </td>
		<td> 
			<input type="radio" name="rdostatus" value="active" 
			<?php if ($status == 'active') 
			{
				echo "checked ";
			} ?>
			>  Active 

			<input type="radio" name="rdostatus" value="inactive" 
			<?php if ($status == 'inactive') 
			{
				echo "checked ";
			} ?>
			>  Inactive 

			
		 </td>
	</tr>

	<tr>
		<td> Registered By Staff of ID:  </td>
		<td> <?php echo "$s_id"; ?> </td>
	</tr>

	<tr>
		<td colspan="2" align="right">
			<br>
			<a href="guestlist.php" id="back" style="float: left;"> &#8592; Back </a>
			<input type="submit" name="btnupdate" value="Update" id="submit"><input type="reset" name="btncancel" value="Cancel" id="cancel">
		</td>
	</tr>
</table>
</form>


</body>
</html>