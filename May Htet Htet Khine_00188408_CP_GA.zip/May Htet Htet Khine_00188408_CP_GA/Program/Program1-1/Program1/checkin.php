<?php 

session_start();
include 'connection.php';
include 'autoid.php';

			
			

if (isset($_POST['btnsubmit'])) 
{
	$resid = $_POST['txtresid'];
	$query = " UPDATE reservation
				SET reservation_status = 'Received'
				WHERE reservation_id = '$resid'";

	$run = mysqli_query($connection, $query);
	if ($run) 
	{

		//$io = 
		//$insert = "INSERT into checkin("

		echo "<script>window.alert('Status updated.') </script>"; 
		echo "<script>window.location = 'checkin.php'</script>";

	}
}
			
 ?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Check in page</title>
</head>
<body>
	
		<legend> Reservations </legend>


		<table>
			<tr>
			<th> R-ID</th>
			<th> Reservation date </th>
			<th> Check-in date </th>
			<th> Check-out date </th>
			<th> Room Number </th>
			<th> Guest Name </th>
			<th> Action </th>
			</tr>
			
			<?php 
		 $query = "SELECT *
				FROM reservation r, reservationdetail rd, guest g
				WHERE r.reservation_id = rd.reservation_id
				AND r.guest_id = g.guest_id";

			$run1 = mysqli_query($connection, $query);
			$count = mysqli_num_rows($run1);
		for ($i=0; $i < $count ; $i++) 
		{ 

			$r_array = mysqli_fetch_array($run1);

			$resid = $r_array['reservation_id'];
			$rdate = $r_array['reservation_date'];
			$room = $r_array['room_id'];
			$guestname = $r_array['guest_name'];
			$datein = $r_array['checkindate'];
			$dateout = $r_array['checkoutdate'];

			echo "<tr>";

			echo "<td> $resid </td> ";
			echo "<td> $rdate </td> ";
			echo "<td> $datein </td> ";
			echo "<td> $dateout </td> ";
			echo "<td> $room </td> ";
			echo "<td> $guestname </td> ";
			
			?>
		<form action="checkin.php" method="post"> 
		<td>
			<input type="text" name="txtresid" readonly="" value="<?php echo $resid; ?>">
			<input type="radio" name="rdocheckin" value="checkin_now"> Check In Now
			<input type="radio" name="rdocheckin" value="cancel"> Cancel 

			<input type="submit" name="btnsubmit" value="Submit">
		</td>

		<?php
		}

	 ?>


		</table>

	</form>
</body>
</html>