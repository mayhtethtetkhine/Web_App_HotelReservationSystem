<?php 
session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{

	$sid= $_GET['st_id'];
	$select = "SELECT * FROM staff WHERE staff_id = '$sid'";
	$selectrun = mysqli_query($connection, $select);
	$count = mysqli_num_rows($selectrun);
	$array = mysqli_fetch_array($selectrun);

}


 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<title> Staff Profile View </title>
 	 <style type="text/css">
 		

table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	text-decoration: none;
	background-color: #BFC5E3;
}


#update
{
	font-size: 15px;
	color: black;
	padding: 12px;
	text-decoration: none;
	font-weight: bold;
	background-color: #87CEFA;
	margin: 15px;
}

#delete
{
	font-size: 15px;
	color: white;
	padding: 12px;
	text-decoration: none;
	font-weight: bold;
	background-color: #d11a2a;
	margin-top:  15px;
}


 	</style> 
 </head>
 <body>
 	<form action="staffprofile.php"> 

<?php 

$id = $array['staff_id'];
$name = $array['staff_name'];
$position = $array['staff_position'];
$email = $array['staff_email'];
$phone = $array['staff_phone'];


$_SESSION['s_id']= $id;


 ?>
<table align="center" width="100%">
	<tr>
		<th colspan="2"><h1> Staff Profile </h1> </th>
	</tr>
	<tr>
		<td> ID </td>
		<td> <?php echo "$id"; ?> </td>
	</tr>
	<tr>
		<td> Name </td>
		<td> <?php echo "$name"; ?> </td>
	</tr>
	<tr>
		<td> Position </td>
		<td> <?php echo "$position"; ?> </td>
	</tr>
	<tr>
		<td> Email </td>
		<td> <?php echo "$email"; ?> </td>
	</tr>
	<tr>
		<td> Phone </td>
		<td> <?php echo "$phone"; ?></td>
	</tr>
</table>
<br>
<p ><!-- align="right"> -->
	<a href="dashboard.php" id="back" style="float: left ;"> Back </a>
	<a href="staffupdate.php" id="update" style="margin-right: 10px; float: right;"> Update </a>
	<a href="staffdelete.php?st_id=$id" id="delete" style="float: right;"> Delete </a>
	
</p>









 	</form>
 </body>
 </html>