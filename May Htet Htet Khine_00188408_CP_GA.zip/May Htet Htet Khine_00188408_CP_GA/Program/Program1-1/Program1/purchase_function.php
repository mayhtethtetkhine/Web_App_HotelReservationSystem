<?php 
function Reserve_room($checkin, $checkout, $roomtype, $roomid, $guestid)
//product id, puchase price, quantity
{

	inclue('connection.php');

	$query = "SELECT * FROM staff WHERE roomtype_id = '$roomtype'";
	$runcheckemail = mysqli_query($connection, $checkemail);
	$count = mysqli_num_rows($runcheckemail);
	$rows = mysql_fetch_array($ret);
	if ($count < 1 ) 
	{
		echo "<p> No room found </p>";
		exit();
	}
	if ($quantity<1) 
	{
		echo "<p> Error: Quantity is less than 1 </p>";
	}
	if ( isset($_SESSION['purchase_function'])) 
	{
		$index = indexof($ProductID);

		//condt2
		if ($index == -1) 
		{

		$count = count($_SESSION['purchase_function']); 
			
		$_SESSION['purchase_function'][$count]['ProductID'] = $productid;
		$_SESSION['purchase_function'][$count]['ProductID'] = $productprice;
		$_SESSION['purchase_function'][$count]['ProductID'] = $quantity;
		}
		//condt3
		else
		{
			$_SESSION['purchase_function'][$index]['ProductID'] = $quantity;
		}
	}
	else
	{
		$_SESSION['purchase_function'] = array(); 
		
		$_SESSION['purchase_function'][0]['ProductID'] = $productid;
		$_SESSION['purchase_function'][0]['ProductID'] = $productprice;
		$_SESSION['purchase_function'][0]['ProductID'] = $quantity;

		$_SESSION['purchase_function'][0]['Product_name'] = $rows['Productname'];



	}
	echo "<script> window.location = 'Purchase_order.php></script>";

}



function RemoveProduct($ProductID)
{
	$index = indexof($ProductID);

	unset($_SESSION['purchase_function'][$index]);
	$_SESSION['purchase_function']=array_values($_SESSION['purchase_function']);
	echo "<script> window.location = 'Purchase_order.php></script>";
}


function clearall()
{
	unset($_SESSION['purchase_function']);
	echo "<script> window.location = 'Purchase_order.php></script>";
}


function calculatetotalamount ()

{
	$totalamount = 0;
	$count = count($_SESSION['purchase_function'])
	for ($i=0; $i < $count ; $i++) 
	{ 
		$Pprice= $_SESSION['purchase_function'][$i]['ProductID'] = $productprice;
		$Pquantity=$_SESSION['purchase_function'][$i]['ProductID'] = $quantity;
		$totalamount += ($Price * $Pquantity);
	}
	return $totalamount;
}



function calculatetotalquantity ()

{
	$totalquantity = 0;
	$count = count($_SESSION['purchase_function'])
	for ($i=0; $i < $count ; $i++) 
	{ 
		$Pquantity=$_SESSION['purchase_function'][$i]['ProductID'] = $quantity;
		$totalamount += $Pquantity);
	}
	return $totalquantity;
}









 function indexof ($productid)
 {
 	//linear search
 	if (!isset($_SESSION['Purchase'])) 
 	{
 		return -1;
 	}
 	$size = count ($_SESSION['purchase_function']);

 	if ($size<1) 
 	{
 		return -1;
 	}

 	for ($i=0; $i < $size ; $i++) 
 	{ 
 		if ($productid == $_SESSION['purchase_function'][$i]['productid']) {
 			// code...
 		}
 	}
 }


 ?>