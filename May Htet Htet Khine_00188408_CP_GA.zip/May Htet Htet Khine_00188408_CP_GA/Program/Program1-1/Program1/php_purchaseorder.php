<?php 

session_start();
include ('connection.php');
include ('autoid.php');
include ('purchase_function.php');

if (isset($_POST['btnadd'])) 
{
	$ProductID = $_POST['cboProductID'];
	$purchaseprice = 
	$quantity= 


	Reserve_room($ProductID, $purchaseprice, $quantity); 
}

if (isset($_GET['action'])) 
{
	$action = $_GET['action'];
	if ($action === 'remove') 
	{
		RemoveProduct($ProductID);
	}
	elseif ($action === 'clearall') 
	{
		clearall($ProductID);
	}

}

if (isset($_POST['btnsave'])) 
{
	$
}


 ?>
}
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Purchase order </title>
</head>
<body>
<form action="purchase_order" method="post">
	
<fieldset>
	<legend> Purchase Order form </legend>
	<table cellpadding="4px">
		<tr>
			<td>
				PO date
				<input type="text" name="txtpodate" value= "<?php echo date ('Y-m-d')?>" readonly>
			</td>
			<td>
				Total amount
				<input type="text" name="txttotalamount" value="0" readonly>
			</td>
		</tr>
		<tr>
		<td> Purchase order <input type="text" name="ponumber" value="<?php echo  ?>" > </td>

	</tr>
		<tr>
			<td>
				Total Quantity
				<input type="text"  name="txtvat" value="<?php echo calculatetotalquantity() ?>">
			</td>
		</tr>
		<tr>
			<td>
				Total amount
				<input type="text"  name="txtvat" value="<?php echo calculatetotalamount() ?>">
			</td>
		</tr>
		<tr>
			<td>
				VAT
				<input type="text"  name="txtvat" value="<?php echo calculatetotalamount() * 0.05  ?>">
			</td>
		</tr>


		<tr>
			<td>
				Staff
				<input type="text" name="txtstaff" value="<?php echo $_SESSION['staff_name'] ?> ">
			</td>
		</tr>
		<tr>
			<td> Purchase Price </td>
			<td> <input type="number" name="txtpurchaseprice" value="0"></td>
		</tr>
		<tr>
			<td> Purchase Quantity </td>
			<td> <input type="number" name="txtpurchaseprice" value="0"></td>
		</tr>
		<tr>
			<td></td>
			<td>
				<input type="submit" name="btnadd" value="Add">
				<input type="reset" name="btnadd" value="Clear">
			</td>
		</tr>

	</table>

	<hr/>
<?php 

if (!isset($_SESSION['Purchase_function']))
{
	echo "<p> No purchase record </p>";
}
 	
 } ?>
<table border="1">
	<tr>
		<th> Product ID</th>
		<th> Product name</th>
		<th> Product price</th>
		<th> QUantity</th>
		<th> subtotal</th>
		<th> action </th>
	</tr>
	
	<?php 
	$size = count($_SESSION['Purchase_function'])
	for ($i=0; $i < ; $i++)
	{ 
		echo "<tr>";
		echo "<td>".$_SESSION['Purchase_function'][$i]['Product_name']."</td>";
		echo "<td>".$_SESSION['Purchase_function'][$i]['Product_price']."</td>";
		echo "<td>".$_SESSION['Purchase_function'][$i]['Product_quantity']."</td>";
		echo "<td>".$_SESSION['Purchase_function'][$i]['Product_name']."</td>";
		echo "<td>
		<a href='Purchase_order.php?ProductID=$ProductID&action=remove'> Remove </a> </td>";
		echo "</tr>";
	}


	 ?>
	 <tr>
	 	<a href="purchase_order.php?action=clearall"> Clear all </a>
	 </tr>

<tr>
	<td>
		
		choose supplier :
		<select name="cbosupplierid">
			<option> choose supplier </option>
			<?php 

			$s_query = "SELECT * "

			 ?>


		</select>
	</td>

</tr>

</table>



<hr/>



</fieldset>



</form>
</body>
</html>