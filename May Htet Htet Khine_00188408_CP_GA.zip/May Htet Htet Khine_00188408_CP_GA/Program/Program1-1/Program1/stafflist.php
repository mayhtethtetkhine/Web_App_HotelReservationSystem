<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	$select = "SELECT * FROM staff";
	$runselect = mysqli_query($connection, $select);
	$count = mysqli_num_rows($runselect);


	//staff session
	$id = $_SESSION['s_id'];
	
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 
	{
		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];
	}


}

else
{
	echo "<script>window.alert('ERROR: Please Log in first.') </script>"; 
	echo "<script>window.location = 'stafflogin.php'</script>";
}




 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<!-- <style type="text/css">
		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}



	</style> -->


<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


	</script>

</head>
<body>
	<h1> Staff List </h1>

	<table  id="tableid" class="display" >
		<thead>
		<tr>
		<th> Name </th>
		<th> Position </th>
		<th> Action </th>
		</tr>
		</thead>
		<tbody>
		<?php 

		for ($i=0; $i < $count ; $i++) 
		{ 
			$array=mysqli_fetch_array($runselect);

			$id=$array['staff_id'];
			$name=$array['staff_name'];
			$position=$array['staff_position'];
			$phone = $array['staff_phone'];

			echo "<tr align = center > ";
			echo " <td> $name </td> ";
			echo " <td> $position </td> ";
			echo " <td> <a href= staffprofile.php?st_id=$id> View Profile </a> </td> ";
			echo " </tr>";

		}

		?>

</tbody>
	</table>
<br>
<a href="dashboard.php" id="back"> &#8592; Back </a>

</body>
</html>