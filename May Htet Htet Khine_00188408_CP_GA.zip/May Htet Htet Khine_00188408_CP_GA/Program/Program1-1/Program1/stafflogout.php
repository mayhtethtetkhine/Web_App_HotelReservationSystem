<?php 
session_start();
session_destroy();

echo "<script> window.alert ('Logged out.')</script>";
echo "<script> window.location='stafflogin.php' </script>";

 ?>