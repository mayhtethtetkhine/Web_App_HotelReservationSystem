<?php 

session_start();
include 'connection.php';




if (isset($_POST['btnsubmit'])) 
{
	$roomid = $_POST['txtid'];
	$status = $_POST['cbostatus'];
	$type = $_POST['cbotype'];

	$update = 	"UPDATE room 
				SET	room_status = '$status', 
				roomtype_id = '$type'
				WHERE room_id = '$roomid'";

	$run = mysqli_query($connection, $update);
	if ($run) 
	{
		echo "<script>window.alert('SUCCESS: Room updated.')</script>";
		echo "<script>window.location='dashboard.php'</script>";
	}
}

if (isset($_GET['number'])) 
{
	$num = $_GET['number'];

	$select = "SELECT * FROM room r, roomtype rt where r.room_id = '$num' AND rt.roomtype_id = r.roomtype_id ";
	$run = mysqli_query($connection, $select);
	$array = mysqli_fetch_array($run);


}

 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title> Update Room </title>
 </head>
 <body>
<form action="roomupdate.php" method="post">
<table align="center" width="100%;">
	
	<?php 
	
 	?>
	
	<tr>
		<th colspan="2"><h1> Update Room </h1></th>
	</tr>
	<tr>
		<td> Images </td>
		<td> 
			<img src= "<?php echo  $array['room_img']; ?>" width = 250px height= 200px>
			<img src= "<?php echo  $array['room_img2']; ?>" width = 250px height= 200px>
		</td>
	</tr>
	<tr>
		<td>Room Number</td>
		<td> <input type="text" name="txtid" readonly="" value="<?php echo $array['room_id']; ?> "></td>
	</tr>
	<tr>
		<td>Room Status</td>
		<td>
			<select name="cbostatus" >

				<?php 
				if ($array['room_status'] == 'available') 

				{
					echo"<option value='available' selected> Available </option>";
					echo" <option value='outoforder'> Out of Order </option>";
				}
				elseif ($array['room_status'] == 'outoforder') 

				{
					echo"<option value='available' > Available </option>";
					echo" <option value='outoforder' selected> Out of Order </option>";
				}



				 ?>
				
			</select>

		</td>
	</tr>
	
	<tr>
		<td> Room Type </td>
		<td>
			<select name="cbotype" value= <?php echo $array['roomtype_name']; ?>>
			<?php 

				$selecttype = "SELECT * FROM roomtype";
				$selecttyperun = mysqli_query($connection, $selecttype);
				$counttype = mysqli_num_rows($selecttyperun);
				for ($i=0; $i < $counttype ; $i++) 
				{ 
					$array = mysqli_fetch_array($selecttyperun);
					$id = $array['roomtype_id'];
					$type = $array['roomtype_name'];
					echo "<option value='$id'> $type </option>";
				}

				 ?>				

			</select>
		</td>
	</tr>
	<tr>
		<td colspan="2" align="right"> 
			<br>
			<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back </a>
			
			<input type="submit" name="btnsubmit" value="Update" id="submit">
			<input type="reset" name="btncancel" value="Cancel" id="cancel">
		</td>
	</tr>

</table>
 </form>	
 </body>
 </html>