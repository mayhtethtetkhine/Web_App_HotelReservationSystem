<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	$id = $_SESSION['s_id'];

	
if(isset($_POST['btnSearch'])) 
{
	$rdoSearchType=$_POST['rdoSearchType'];

	if($rdoSearchType == 1) 
	{
		$roomid=$_POST['cboroomid'];

		$query="SELECT r.*, rt.*
				FROM room r, roomtype rt
				WHERE r.room_id ='$roomid'
				AND r.roomtype_id = rt.roomtype_id
				";
		$ret=mysqli_query($connection,$query);
	}
	/* elseif($rdoSearchType == 2)
	{
		$From=date('Y-m-d',strtotime($_POST['txtFrom']));
		$To=date('Y-m-d',strtotime($_POST['txtTo']));



		$query="SELECT r.*, res_d.*, rt.*, res.*
				FROM room r, roomtype rt, reservation res, reservationdetail res_d
				WHERE res_d.checkin_date  BETWEEN '$From' AND '$To'
				AND r.room_id = res.d_room_id 
				";
		$ret=mysqli_query($connection,$query);
	} */

	elseif($rdoSearchType == 2)
	{
		$cboStatus=$_POST['cboStatus'];

		$query="SELECT r.*, rt.*
				FROM room r, roomtype rt
				WHERE r.room_status='$cboStatus'
				AND r.roomtype_id = rt.roomtype_id
				";
		$ret=mysqli_query($connection,$query);
	}
}
else  
{
	$query="SELECT r.*, rt.*
			FROM room r, roomtype rt
			WHERE r.roomtype_id = rt.roomtype_id
			";
	$ret=mysqli_query($connection,$query);
}


}
else
{
	echo "<script>window.alert('Please login first. ') </script>"; 
	echo "<script>window.location = 'stafflogin.php'</script>";
}



 ?>
<!DOCTYPE html>
<html>
<head>
	<title> Room search </title>
	<!-- <style type="text/css">
		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	text-decoration: none;
	background-color: #BFC5E3;
}

	</style>
 -->


<script type="text/javascript" src="datejs/datepicker.js"></script>
<link rel="stylesheet" type="text/css" href="datecss/datepicker.css" />



</head>
<body>
	<form action="roomcheck.php" method="post">
<fieldset>
<legend>Room Search :</legend>
<table cellpadding="5px">
<tr>
	<td>
		<input type="radio" name="rdoSearchType" value="1" checked />Search by Room Number
		<br/>
		<select name="cboroomid">
			<option>--Choose Room Number--</option>
			<?php  
			$r_query="SELECT * FROM room";
			$r_ret=mysqli_query($connection,$r_query);
			$r_count=mysqli_num_rows($r_ret);

			for ($i=0;$i<$r_count;$i++) 
			{ 
				$r_arr=mysqli_fetch_array($r_ret);
				$RoomID=$r_arr['room_id'];
				echo "<option value='$RoomID'> $RoomID</option>";
			}
			?>
		</select>
	</td>
	<!-- <td>
		<input type="radio" name="rdoSearchType" value="2" />Search by Date
		<br/>
		From <input type="text" name="txtFrom" value="<?php echo date('Y-m-d') ?>" onClick="showCalender(calender,this)"/>
		To <input type="text" name="txtTo" value="<?php echo date('Y-m-d') ?>" onClick="showCalender(calender,this)" />
	</td> -->
	<td>
		<input type="radio" name="rdoSearchType" value="2" />Search by Status
		<br/>
		<select name="cboStatus">
			<option>available</option>
			<option>reserved</option>
		</select>
	</td>
	<td>
		<br/>
		<input type="submit" name="btnSearch" value="Search" />
		<input type="reset" value="Clear" />
	</td>
</tr>
</table>
<hr/>
<?php  
$count=mysqli_num_rows($ret);

if($count < 1) 
{
	echo "<p>No Record Found.</p>";
}
else
{
?>
	<table border="1" width="100%">
		<tr>
			<th>#</th>
			<th>Room ID </th>
			<th>Room Type </th>
			<th>Status</th>
			<th>Action</th>
		</tr>
		<?php 
		for($i=0;$i<$count;$i++) 
		{ 
			$row=mysqli_fetch_array($ret);
			$roomid=$row['room_id'];

			echo "<tr>";
				echo "<td>" . ($i+1) . "</td>";
				echo "<td>". $roomid ."</td>";
				echo "<td>". $row['roomtype_name'] ."</td>";
				echo "<td>". $row['room_status'] ."</td>";
				
				echo "<td> 
						<a href='reservation.php?roomid=$roomid'>Reservations</a> 
					  </td>";
			echo "</tr>";
		}
		?>
	</table>
<?php
}
?>
<hr/>
</fieldset>
</fieldset>
</form>
</body>

</html>