<?php 

session_start();
include 'connection.php';

if (isset($_SESSION['s_id'])) 
{
	$id = $_GET['guest_id'];
	$guestselect = "SELECT * FROM guest WHERE guest_id = '$id'";
	$selectrun = mysqli_query($connection, $guestselect);
	$count = mysqli_num_rows($selectrun);
	$g_array = mysqli_fetch_array($selectrun);

	if ($count<1) 
	{
		echo "<script> window.alert('Error: Guest data not found. ')</script>";
		echo "<script> window.location='guestlist.php' </script>";
	}
}


else
{
	echo "<script> window.alert('Error: Please log in. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";
}


 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<title> Profile </title>
<style type="text/css">

		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#update
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
}


</style>
 </head>
 <body>
 

<?php 

$id = $g_array['guest_id'];
$name = $g_array['guest_name'];
$nrc = $g_array['guest_nrc'];
$phone = $g_array['guest_phone'];
$status = $g_array['guest_status'];
$s_id = $g_array['staff_id'];

$_SESSION['g_id'] = $g_array['guest_id'];

 ?>


 <form action="guestprofile.php" method="post">

 <table align="center" width="100%">
 	<tr>
 		<th colspan="2"><h1> Guest Profile </h1></th>
 	</tr>
	<tr>
		<td> Guest ID: </td>
		<td> <?php echo "$id"; ?> </td>
	</tr>

	<tr>
		<td> Name </td>
		<td>  <?php echo "$name" ; ?> </td>
	</tr>

	<tr>
		<td> NRC </td>
		<td> <?php echo "$nrc"; ?> </td>
	</tr>

	<tr>
		<td> Phone </td>
		<td> <?php echo "$phone"; ?> </td>
	</tr>
	<tr>
		<td> Status </td>
		<td> <?php echo "$status"; ?> </td>
	</tr>

	<tr>
		<td> Registered By StaffID:  </td>
		<td> <?php echo "$s_id"; ?> </td>
	
</table>
	<br>
	<p align="left">
		<a href="guestlist.php" id="back" > &#8592; Back </a> 
		<a href="guestupdate.php" id="update" style="float: right;"> Update </a>
	</p>	


 	


 </form>

 </body>
 </html>