<?php

include ('connection.php');
$rid= $_GET['number'];
$delete = "DELETE FROM room WHERE room_id = '$rid'";
$rundelete = mysqli_query($connection, $delete);

if($rundelete)
{
	echo"<script> window.alert ('SUCCESS: Room deleted.')</script>";
	echo"<script> window.location= 'room.php'</script>";
}
else
{
	echo mysqli_error($connection);
}
?>