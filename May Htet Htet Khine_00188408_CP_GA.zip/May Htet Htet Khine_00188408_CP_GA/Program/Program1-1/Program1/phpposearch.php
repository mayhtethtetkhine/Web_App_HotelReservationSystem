<?php 

session_start();
include ('connection.php');


if (isset($_POST['btnsearch'])) 
{
	// code...
}

elseif (isset($_POST['btnshowall'])) 
{
	$query = "SELECT po.*, s.SupplierID, s.SupplierName from purchaseorder po, supplier s where po.supplierid = s.supplierid";
	$ret = mysqli_query ($connection, $query);
}
else
{
	$today = date('y-m-d');
	$query = "SELECT po.*, s.SupplierID, s.SupplierName from purchaseorder po, supplier s where po.purchaseorderdate = '$Today' and po.supplierid = s.supplierid";
	$ret = mysqli_query ($connection, $query);
}

 ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>purchase search and report</title>
</head>
<body>
<form action="php_po_search.php" method="post"></form>
<fieldset>
	<legend> purchase order search </legend>
	<br>
	<table>
	<tr>
		<td>
			<input type="radio" name="rdosearchtype" value="1" checked=""> Search by ID 
				<select name="cbopurchaseorderid">
					<option>--choose poid--</option>
			<?php 



			 ?>
		</select>
		</td>
		<td>
			<input type="radio" name="rdosearchtype" value="2"> Search by Date 
			<br>
				From
				<input type="text" name="txtfrom" value= "<?php echo date('Y-m-d'); ?>" >
				To
				<input type="text" name="txtto" value="<?php echo date('Y-m-d'); ?>">
		</td>
		<td>
			<input type="radio" name="rdosearchtype" value="3"> Search by Status 
			<br>
			<input type="radio" name="rdosearchtype" value="3" checked=""> Search by status 
				<select name="cbostatus">
					<option>--choose status--</option>
			<?php 



			 ?>
		</select>

		</td>
	</tr>
</table>
</fieldset>

<hr/>

<?php 
$count = mysqli_num_rows($ret);
if ($count<1) 
{
	echo "<p> No record found </p> ";
}

else
{
	
 
}
?>

<table width="100%" >
	<tr>
		<th> # </th>
		<th> PO- ID</th>
		<th> PO- Date </th>
		<th> suppliername</th>
		<th> total amount</th>
		<th> total quantity </th>
		<th> vat</th>
		<th> grandtotal</th>
		<th> status</th>
		<th> action</th>


	</tr>
	<?php 

	for ($i=0; $i < $count ; $i++) 
	{ 
		$row = mysqli_fetch_array ($ret);
		$poid = $row['purchaseorderid'];

		echo "<tr>";
		echo "<td>".($i+1)."</td>";
		echo "<td>".$poid."</td>";
		echo "<td>".$row['PurchaseOrderDate']."</td>";
		echo "<td>".$row['SupplierName']."</td>";
		echo "<td>".$row['TotalAmount']."</td>";
		echo "<td>".$row['totalquantity']."</td>";
		echo "<td>".$row['totalquantity']."</td>";
		echo "<td>".$row['vat']."</td>";
		echo "<td>".$row['grandtotal']."</td>";
		echo "<td>".$row['status']."</td>";
		;
		echo "</tr>";
	}
	 ?>
</table>

<hr/>


</body>
</html>