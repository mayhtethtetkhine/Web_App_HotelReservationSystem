<?php 
session_start();
include 'autoid.php';
include 'connection.php';



if (isset($_POST['btnsubmit'])) 
{	
	$rid = $_POST['txtrid'];
	$rdid = $_POST['txtrdid'];
	$in = $_POST['datein'];
	$out = $_POST['dateout'];
	$room = $_POST['txtroom'];
	$g = $_POST['cboguestname']; 
	$rstatus ="active";
	$date = $_POST['txtdate'];
	$_SESSION['reservationid'] = $rid; 
	$insert = "INSERT INTO reservation (reservation_id, reservation_status, reservation_date, guest_id ,checkindate, checkoutdate) VALUES ('$rid','$rstatus','$date','$g','$in','$out')";
	$runinsert = mysqli_query($connection, $insert);
	// if ($runinsert) 
	// {
		
		$insert2 = "INSERT INTO reservationdetail (reservation_id, room_id ) VALUES ('$rid', '$room')";
		$runinsert2 = mysqli_query($connection, $insert2);
		if ($runinsert2) 
		{
			echo "<script>window.alert('Reservation complete.')</script>";
			echo "<script>window.location='dashboard.php'</script>";
		}
		// else
		// {
		// echo mysqli_error($connection);
		// echo "<script>window.location='dashboard.php'</script>";
		// }
		
	//}
	// else
	// {
	// 	echo mysqli_error($connection);
	// 	echo "<script>window.location='dashboard.php'</script>";
	// }

//rd details

	



}


 ?>





<!DOCTYPE html>
<html>
<head>

<script type="text/javascript" src="datepicker.js"></script>
<link href="datecss/datepicker.css" rel="stylesheet" type="text/css">

	<title> Reservation Form </title>

<!-- <style type="text/css">

table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #c5e3bf;
}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}

</style> -->

</head>
<body >
	
		
<form action="reservation.php" method="post">
	<table align="center" width="100%"> 
		<tr>
			<th colspan="4"> <h1> Reservation </h1> </th>
		</tr>
		<tr>
			<td> Reservation ID</td>
			<td><input type="text" name="txtrid" readonly="" value="<?php echo auto_id('reservation','reservation_id','RV-',6) ?>"></td>
			<td> RD ID</td>
			<td><input type="text" name="txtrdid" readonly="" value="<?php echo auto_id('reservationdetail','reservation_id','RD-',6) ?>"></td>
		</tr>
		<tr>
			<td> Guest Name </td>
			<td> 
				<select name = "cboguestname">
					<?php 

					$selectname= "SELECT guest_id, guest_name FROM guest where guest_status = 'active' ";
					$run = mysqli_query($connection, $selectname);
					$count = mysqli_num_rows($run);
					

					for ($i=0; $i < $count ; $i++) 
					{ 
						$arr = mysqli_fetch_array($run);
						$id = $arr['guest_id'];
						$name = $arr['guest_name'];
						echo "<option value = $id> $id : $name </option> ";
					}

					 ?>


				</select>
			</td>
		</tr>
		<tr>
			<td> Reservation date </td>
			<td> <input type="text" name="txtdate" readonly="" value=" <?php echo date('Y-m-d'); ?>"></td>
		</tr>
				
		<tr>
			<td> Room </td>
			<td> 
				<?php 

				if (isset($_GET['roomid'])) 
				{
					$rid = $_GET['roomid'];
					$select = "SELECT r.*, rt.* FROM room r, roomtype rt 
					WHERE r.room_id = $rid
					AND r.roomtype_id = rt.roomtype_id";
					$run = mysqli_query($connection, $select);
					$array = mysqli_fetch_array($run);

					$_SESSION['roomid'] = $array['room_id'];

				}
				
				?>

				 <input type="text" name="txtroom" readonly="" value="<?php 
				 echo $array['room_id']; ?>">

			</td>
			
		</tr>
	
 		
 		<tr>
			<td> Expected Check in date </td>
			<td> <input type="text" name="datein" onClick="showCalender(calender,this)" placeholder="Select Check-in date" ></td>
		
			<td> Expected Check out date </td>
			<td> <input type="text" name="dateout" onClick="showCalender(calender,this)"  placeholder="Select Check-out date" ></td>
		</tr>
		
		
		<tr>
			<td colspan="2" align="right"> 
				<br>
				<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back </a>
			</td>
			<td>
				<input type="submit" name="btnsubmit" value="Next" id="submit">
				<input type="reset" value="Cancel" id="cancel">
			</td>
		</tr>

 	</table>
 	</form>

</body>
</html>