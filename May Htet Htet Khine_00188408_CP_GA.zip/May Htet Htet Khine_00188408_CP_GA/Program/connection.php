<?php 

$host = "localhost";
$user = "root";
$pass = "";
$database = "project";

$connection = mysqli_connect($host,$user,$pass,$database) or die("ERROR: Database Connection Failed. ");


 ?>