<?php 

session_start();
include 'connection.php';
include 'header.php';
include 'maindash.php';
if (isset($_SESSION['s_id'])) 
{
	
	$id = $_SESSION['s_id'];
	$name= $_SESSION['s_name'];
	$position = $_SESSION['s_position'];
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);

	if ($countstaff > 0 ) 
	{
		// echo "<h1 id= back align=center > Using: $name <br> Position: $position  </h1>";
		

		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];


	}

	else
	{
		echo "<script> window.alert('Error: Please log in again. ')</script>";
		echo "<script> window.location='stafflogin.php' </script>";
	}



}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title> Dashboard </title>
</head>


<!-- 
<a href="staffregister.php"> Register staff </a><br>
<a href="roomtypes.php"> Add room type </a> <br>
<a href="room.php"> Add room </a> <br>
<a href="stafflist.php"> staff list </a> <br>
<a href="guestlist.php"> view guests </a> <br>
<a href="guest.php"> add guest </a> <br>
<a href="roomcheck.php"> Available Rooms </a> <br>
<a href="stafflogout.php"> Log out </a> <br>
<a href="checkin.php"> Check In </a> <br>
<a href="checkout.php"> Check Out</a> <br>
<a href="paymentlist.php"> Payments </a> -->

</html> 