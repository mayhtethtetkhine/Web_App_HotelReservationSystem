<?php 

session_start();
include 'connection.php';
include 'header2.php';		

if (isset($_SESSION['s_id'])) 
{

	$id = $_SESSION['s_id'];
	$selectstaff = "SELECT * FROM staff WHERE staff_id = '$id'";
	$selectstaffrun = mysqli_query($connection, $selectstaff);
	$countstaff = mysqli_num_rows($selectstaffrun);
	$array = mysqli_fetch_array($selectstaffrun);
	if ($countstaff > 0 ) 

	{

		$query = "SELECT r.*, rd.* , g.*
				FROM reservation r, reservationdetail rd, guest g
				WHERE r.reservation_id = rd.reservation_id
				AND r.guest_id = g.guest_id
				AND r.reservation_status = 'active'";

			$run = mysqli_query($connection, $query);
			$count = mysqli_num_rows($run);

		$_SESSION['s_id'] = $array['staff_id'];

					
		if(isset($_POST['btnSearch'])) 
		{
			$rdoSearchType=$_POST['rdoSearchType'];

			if($rdoSearchType == 1) 
			{
				$rid=$_POST['txtrid'];

				$query = "SELECT r.*, rd.* , g.*
							FROM reservation r, reservationdetail rd, guest g
							WHERE r.reservation_id = rd.reservation_id
							AND r.guest_id = g.guest_id
							AND r.reservation_status = 'active'
							AND r.reservation_id ='$rid'";
				$run=mysqli_query($connection,$query);
				$count = mysqli_num_rows($run);

			}
			
			elseif($rdoSearchType == 2)
			{
				$date=date('Y-m-d',strtotime($_POST['txtrdate']));

				$query = "SELECT r.*, rd.* , g.*
							FROM reservation r, reservationdetail rd, guest g
							WHERE r.reservation_id = rd.reservation_id
							AND r.guest_id = g.guest_id
							AND r.reservation_status = 'active'
							AND r.reservation_date ='$date'";
				$run=mysqli_query($connection,$query);
				$count = mysqli_num_rows($run);
			}

			elseif($rdoSearchType == 3)
			{
				$cdate=date('Y-m-d',strtotime($_POST['txtcdate']));

				$query = "SELECT r.*, rd.* , g.*
							FROM reservation r, reservationdetail rd, guest g
							WHERE r.reservation_id = rd.reservation_id
							AND r.guest_id = g.guest_id
							AND r.reservation_status = 'active'
							AND r.checkindate ='$cdate'";
				$run=mysqli_query($connection,$query);
				$count = mysqli_num_rows($run);
			}
		
			

		}
		else  
		{
				$query = "SELECT r.*, rd.* , g.*
				FROM reservation r, reservationdetail rd, guest g
				WHERE r.reservation_id = rd.reservation_id
				AND r.guest_id = g.guest_id
				AND r.reservation_status = 'active'";

			$run = mysqli_query($connection, $query);
			$count = mysqli_num_rows($run);

		}

		if (isset($_POST['btnshowall']) )
		{
				$query = "SELECT r.*, rd.* , g.*
				FROM reservation r, reservationdetail rd, guest g
				WHERE r.reservation_id = rd.reservation_id
				AND r.guest_id = g.guest_id
				AND r.reservation_status = 'active'";

			$run = mysqli_query($connection, $query);
			$count = mysqli_num_rows($run);

		}

	}
	else
	{
		echo "<script> window.alert('Error: Please log in again. ')</script>";
		echo "<script> window.location='stafflogin.php' </script>";
	}
}
else
{
	echo "<script> window.alert('Error: Please log in again. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";
}
			
 ?>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Check in </title>

 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />
<script type="text/javascript" src="datepicker.js"></script>
<link href="datecss/datepicker.css" rel="stylesheet" type="text/css">
<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>
<style type="text/css">
	body
	{
		background-color: #768496 ;
	}
	p
	{
		padding: 30px;
		font-size: 20px;
		align-content: center;
	}
	#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
	text-decoration: none;
}
	a
	{
		text-decoration: none;
		color: blue;
	}
	table th
	{
		background-color: #D1D5DA;
		border: 1px solid black;
		color: black;
	}
	table td
	{
		background-color: white ;
		border: 1px solid black;
		color: black;
	}
	
</style> 
</head>
<body>
<form action="checkin.php" method="post">	


<table cellpadding="5px">
	<tr>
	<td width="25%">
		<input type="radio" name="rdoSearchType" value="1" checked />Search by Reservation ID 
		<input type="text" name="txtrid" placeholder="Type reservation id">
	</td>
	<td width="25%">
		<input type="radio" name="rdoSearchType" value="2" />Search by Reservation Date 
		<input type="text" name="txtrdate"  onClick="showCalender(calender,this)" placeholder="Select Reservation Date" >

	</td>	
	<td width="25%">
		<input type="radio" name="rdoSearchType" value="3"  />Search by Check-in Date 
		<input type="text" name="txtcdate"  onClick="showCalender(calender,this)" placeholder="Select Check-in date" >

	</td>
	<td width="20%">

		<input type="submit" name="btnSearch" value="Search" style="float: left;" />
		<input type="submit" name="btnshowall" value="Show All" />

	</td>

	</tr>

</table>

		
		<table id="tableid" class="display" border="1px" width="100%">
			<tr>
				<hr/>
			<th> R-ID</th>
			<th> Reservation date </th>
			<th> Check-in date </th>
			<th> Check-out date </th>
			<th> Room Number </th>
			<th> Guest Name </th>
			<th> Action </th>
			</tr>


<?php 
if ($count < 1) 
{
	echo "<tr > <td colspan = 7 align=center> No Reservation Data Found. </td> </tr>";
}
else
{

			
		
		for ($i=0; $i < $count ; $i++) 
		{ 

			$r_array = mysqli_fetch_array($run);

			$resid = $r_array['reservation_id'];
			$rdate = $r_array['reservation_date'];
			$room = $r_array['room_id'];
			$guestid = $r_array ['guest_id'];
			$guestname = $r_array['guest_name'];
			$datein = $r_array['checkindate'];
			$dateout = $r_array['checkoutdate'];

			echo "<tr>";

			echo "<td> $resid </td> ";
			echo "<td> $rdate </td> ";
			echo "<td> $datein </td> ";
			echo "<td> $dateout </td> ";
			echo "<td> $room </td> ";
			echo "<td> $guestname </td> ";
			


			?>
		
		
		<?php
		echo" <td>	
			<a href= checkinconfirm.php?resid=$resid&s_id=$id> Check In Now </a>
		</td> </tr> ";

}
		
		}

	 ?>


		</table>

	</form>

<br>
 	<a href="dashboard.php" id="back"> &#8592; Back </a>
 
</body>
</html>