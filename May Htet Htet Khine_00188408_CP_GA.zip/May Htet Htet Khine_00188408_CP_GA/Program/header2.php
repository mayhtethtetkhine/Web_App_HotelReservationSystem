<!-- header -->
<!DOCTYPE html>
<html lang="">
<!-- To declare your language - read more here: https://www.w3.org/International/questions/qa-html-language-declarations -->
<head>
<title> Happy Stay Hotel </title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="layout/styles/layout.css" rel="stylesheet" type="text/css" media="all">
</head>
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<!-- ################################################################################################ -->
<div class="wrapper row1">
  <header id="header" class="hoc clear">
    <div id="logo" class="fl_left"> 
      <!-- ################################################################################################ -->
      <h1 class="logoname"><a href="index.html">Happy<span>S</span>tay</a></h1>
      <!-- ################################################################################################ -->
    </div>
    <nav id="mainav" class="fl_right"> 
      <!-- ################################################################################################ -->
      <ul class="clear">
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="paymentlist.php"> Payment List </a></li>
        <li><a href="checkin.php"> Check in </a></li>
        <li><a href="checkout.php">Check out </a></li>

        <li><a href="stafflogout.php"> Log Out </a></li>

      </ul>
      <!-- ################################################################################################ -->
    </nav>
  </header>
</div>