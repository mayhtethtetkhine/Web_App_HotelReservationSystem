<?php 

session_start();
include 'connection.php';
include 'autoid.php';


if (isset($_SESSION['s_id'])) 
{
	$staffid = $_SESSION['s_id'];

	$query = "SELECT p.*, c.* FROM payment p, checkin c  
				WHERE p.io_id = c.io_id
				AND c.check_out = 'Yes' ";
	$run = mysqli_query($connection, $query);
	
}

else
{
	echo "<script> window.alert('Error: Please log in again. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";
}


 ?>


 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title> Payment List </title>
	<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>

<style type="text/css">

body
{
	background-color: #768496;
}
a
{
	text-decoration: none;
}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}
table th
{
	background-color: #D1D5DA;
}

</style> 

 </head>
 <body>
 	<h1> Payment Records </h1>
 	<?php 

		$count = mysqli_num_rows($run);
		if ($count < 0 ) 
		{
			echo "No record found. ";
			
		}
		else
		{
			
		
 	 ?>

 	<table id="tableid" class="display" border="1px">

 		<tr>
 			<th> Payment ID </th>
 			<th> Date </th>
 			<th> Number of days </th>
 			<th> Amount </th>
 			<th> Tax </th>
 			<th> Total Amount </th>
 			<th> Staff ID </th>
 			<th> IO-ID</th>
 			<th> Action </th>
 		</tr>
 		<?php 


		
 		for ($i=0; $i < $count ; $i++) 
 		{ 
 			$array = mysqli_fetch_array($run); 
 			$cout = $array['checkout_date'];
 			$cin = $array['checkin_date']; 


 			//numberofdays
			$out = strtotime($cout);
			$in = strtotime($cin);
			$diff = ($out - $in)/60/60/24;

 			$paymentid = $array['payment_id'];
 			$date = $array['payment_date'];
 			$amount = $array['payment_amount'];
 			$tax = $array['tax'];
 			$total = $amount + $tax; 
 			$staff = $array['staff_id'];
 			$io = $array['io_id'];

 			echo"<tr>";
 			echo "<td> $paymentid </td>";
 			echo "<td> $date </td>";
 			echo "<td> $diff </td>";
 			echo "<td> $amount </td>";
 			echo "<td> $tax </td>";
 			echo "<td> $total </td>";
 			echo "<td> $staff </td>";
 			echo "<td> $io </td>";
 			$_SESSION['s_id'] = $staffid;
 			echo "<td> <a href = payment.php?ioid=$io>View Details</a></td>";
 			echo "</tr>";
 		}
 		






 		} 

 		 ?>

 		
 	</table>

<br>
 	<a href="dashboard.php" id="back"> &#8592; Back </a>
 
 </body>
 </html>