<?php 

session_start();
include 'connection.php';

if (isset($_POST['btnlogin'])) 
{
	$email = $_POST['txtemail'];
	$password = $_POST['txtpassword'];

	$select = "SELECT * FROM staff WHERE staff_email = '$email' AND staff_password = '$password'";

	$selectrun = mysqli_query($connection, $select);


	$selectcount = mysqli_num_rows($selectrun);

	$array = mysqli_fetch_array($selectrun);

	if ($selectcount > 0) 
	{
		$_SESSION['s_id'] = $array['staff_id'];
		$_SESSION['s_name'] = $array['staff_name'];
		$_SESSION['s_position'] = $array['staff_position'];


		echo "<script> window.alert('Logged in') </script>";
		echo "<script> window.location = 'dashboard.php'</script>";
	}

	else
	{
		echo "<script> window.alert('Wrong username or password. ') </script>";
		echo "<script> window.location = 'stafflogin.php'</script>";

	}

}





 ?>




<!DOCTYPE html>
<html>
<head>
	<title> Staff Login </title>


	<style type="text/css">

body
{
	background-color: #768496 ;
}
table
{
	width: 80%;
	border: 1px solid black;
	border-collapse: collapse;
	padding: 10px;

}

table th
{
	border: 1px solid black;
	border-collapse: collapse;
	padding: 10px;
	background-color: #D1D5DA;
	color: black ;
}

table td
{
	width: 50%;
	border: 1px solid black;
	border-collapse: collapse;
	padding: 10px;
	background-color: white;
	color: black ;
}



#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #f08080;
	border: none;
}




	</style>

</head>
<body>

	<form action="stafflogin.php" method="post">
		<table align="center" >
			<tr>
				<th colspan="2"> <h1>Login </h1> </th>
			</tr>
		<tr align="center">
			<td>Email</td>
			<td> <input type="email" name="txtemail" autofocus="" required="" placeholder="abc@mail.com"></td>

		</tr>

		<tr align="center">
			<td>Password</td>
			<td> <input type="password" name="txtpassword" required="" placeholder="Enter password here"></td>

		</tr>
		<tr>
			<td colspan="2" align="right" >
				
				<input type="reset" name="btncancel" value="Reset" id="cancel" >
				<input type="submit" name="btnlogin" value="Log in" id="submit">

			</td>


		</tr>

		</table>
	</form>



</body>
</html>