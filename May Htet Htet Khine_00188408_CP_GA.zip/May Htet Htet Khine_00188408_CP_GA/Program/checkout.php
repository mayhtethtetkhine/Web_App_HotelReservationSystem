<?php 

session_start();
include 'connection.php';
include 'header2.php';

$s_id = $_SESSION['s_id'];

$query = "SELECT c.*, g.*, rd.*, r.* FROM checkin c, guest g, reservation r, reservationdetail rd 
			WHERE c.check_out= 'No'
			AND c.reservation_id = r.reservation_id 
			AND r.reservation_id = rd.reservation_id
			AND g.guest_id = r.guest_id";
$run = mysqli_query($connection, $query);


$count = mysqli_num_rows($run);

 ?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Currently staying guests </title>

 <script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css" />

<script>
		
		$(document).ready (function()
		{
			$('#tableid').DataTable();
		}

		);


</script>

<style type="text/css">
body
{
	background-color: #768496;
}
a
{
	text-decoration: none;
	color: blue;
}

#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}
	table th
	{
		background-color: #D1D5DA;
		border: 1px solid black;
		color: black;
	}
	table td
	{
		background-color: white ;
		border: 1px solid black;
		color: black;
	}

</style>
</head>
<body>

	<?php 

	if ($count<1) 
	{
		echo "<p> No record found. </p> ";

		?>
		<br>
 	<a href=dashboard.php id=back> &#8592; Back </a>

 	<?php
	}
	else
	{

	 ?>
	<form action="checkout.php" method="POST">
		<table id="tableid" class="display" border="1px">
			<tr>
			<th> IO-ID </th>
			<th> Guest Name </th> 
			<th> Room</th>
			<th> Check-in date </th>
			<th> Action </th>
			</tr>
			
				<?php 

				
				for ($i=0; $i < $count ; $i++) 
				{ 

					$array= mysqli_fetch_array($run);
					$ioid = $array['io_id'];
					$g_name = $array['guest_name'];
					$datein = $array['checkin_date'];
					$room = $array['room_id'];


					echo "<tr>";
					echo "<td> $ioid </td> ";
					echo "<td> $g_name </td> ";
					echo "<td> $room </td> ";
					echo "<td> $datein </td> "; 
					$_SESSION['s_id'] = $s_id; 
					echo "<td> <a href= checkoutconfirm.php?ioid=$ioid> Check Out </a> </td> ";
					echo "</tr>";
				}

				 ?>
			
		</table>
		<br>
 	<a href="dashboard.php" id="back"> &#8592; Back </a>
<?php } ?>



	</form>


</body>
</html>