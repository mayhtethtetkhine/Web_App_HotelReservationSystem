<?php 

session_start();
include 'connection.php';
include 'autoid.php';

if (isset($_SESSION['s_position'])) 
{
	$pos = $_SESSION['s_position'];
	if ($pos != 'Data Analyst') 
	{
		echo "<script>window.alert('You do not have access.')</script>";
		echo "<script>window.location='dashboard.php'</script>";
	}
}



if (isset($_POST['btnregister'])) 

{
	$st_id = $_POST['txtsid'];
	$name = $_POST['txtname'];
	$email = $_POST['txtemail'];
	$password = $_POST ['txtpassword'];
	$phone = $_POST['txtphone'];
	$position = $_POST['txtposition'];


	$checkemail = "SELECT * FROM staff WHERE staff_email = '$email' AND staff_password = '$password'";
	$runcheckemail = mysqli_query($connection, $checkemail);
	$count = mysqli_num_rows($runcheckemail);

		if ($count>0) 
		{
			echo "<script>window.alert('ERROR: Duplicate email. Try again using another email. ') </script>"; 
			echo "<script>window.location = 'staffregister.php'</script>";
		}

		else
		{
			$insertstaff = "INSERT INTO staff (staff_id, staff_name , staff_email , staff_password , staff_phone , staff_position ) VALUES ('$st_id','$name', '$email' , '$password', '$phone' , '$position')";

			$runinsert = mysqli_query($connection, $insertstaff);

			if ($runinsert)
			{
				echo "<script>window.alert('SUCCESS: Staff account registered.')</script>";
				echo "<script>window.location='dashboard.php'</script>";
			}

			else
			{
				echo mysqli_error($connection);
				echo "<script>window.location='staffregister.php'</script>";
			}
		}
}


 ?>

<!DOCTYPE html>
<html>
<head>
	<title> Staff Register</title>
	<style type="text/css">
body
{
	background-color: #768496 ;
}	
		
table
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
}

table th
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: #D1D5DA;

}

table td
{
	border: 1px solid;
	border-collapse: collapse;
	padding: 10px;
	background-color: white;

}
a
{
	text-decoration: none;
}


		
#back
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #BFC5E3;
}

#submit
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: #87CEFA;
	border: none;
}

#cancel
{
	font-size: 15px;
	color: black;
	padding: 12px;
	font-weight: bold;
	background-color: white ;
	border: 1px solid black;
}




	</style>


<script type="text/javascript">
	
var checking = function()
		{
			if (document.getElementById('pass').value=='' && document.getElementById('con_pass').value=='' )
			{
				document.getElementById('msg').innerHTML='';
				document.getElementById("submit").disabled = true; 
				
				
			}
			else if (document.getElementById('pass').value == document.getElementById('con_pass').value)
			{
				document.getElementById('msg').innerHTML='(Password confirmed.) ';
				document.getElementById('msg').style.color='green';
				document.getElementById("submit").disabled = false; 
				
			}

			
			else
			{
				document.getElementById('msg').innerHTML='Please make sure your passwords match. ';
				document.getElementById('msg').style.color='red';
				document.getElementById("submit").disabled = true; 
				
			}

			var passwords = document.querySelectorAll(".pw");
			var password = passwords[0].value;
			var confirmpassword = passwords[2].value;
			var btn = document.getElementById("submit");
			
			if (password == confirmpassword) 
			{
				document.getElementById("submit").disabled = false; 
			}
			
		}
	</script>
</head>
<body>


<form action="staffregister.php" method="POST">

<table align="center" width="80%" > 
	<tr>
		<th colspan="2"> <h1> Register staff </h1> </th>
	</tr>
	<tr>
		<td> Staff ID </td>
		<td>
	<input type="text" name="txtsid" value="<?php echo auto_id('staff','staff_id','S-',6) ?>">
	</td>
	</tr>
	<tr>
		<td width="50%"> Name </td>
		<td><input type="text" name="txtname" autofocus="" required="" ></td>
	</tr>

	<tr>
		<td>Position</td>
		<td>
			<select name="txtposition" required=""> 

			<option value="Data Analyst" selected=""> Data Analyst </option>
			<option value="Receptionist" > Receptionist </option>

			</select>
		</td>
	</tr>

	<tr>
		<td>Email </td>
		<td>
			<input type="email" name="txtemail" placeholder="example@domain.com" required="">
		</td>
	</tr>

	<tr>
		<td> Password</td>
		<td>
			<input type="password" name="txtpassword" id="pass" required="" class="pw">
		</td>
	</tr>

	<tr>
		<td>Confirm Password</td>
		<td>
			<p id="msg"></p>

			<input type="password" name="txtconfirmpassword" required="" class="pw" id="con_pass" onkeyup="checking()" >
			
		</td>
		

		
		
	</tr>

	<tr>
		<td>Phone Number </td>
		<td>
			<input type="text" name="txtphone" required="" >
		</td>
	</tr>

	<tr>
		<td colspan="2" align="right">
		<a href="dashboard.php" id="back" style="float: left;"> &#8592; Back </a>
			<input type="submit" name="btnregister" value="Register" id="submit" >
			<input type="reset" name="btncancel" value="Cancel" id="cancel">
		</td>
		
	</tr>



</table>



</form>


</body>
</html>