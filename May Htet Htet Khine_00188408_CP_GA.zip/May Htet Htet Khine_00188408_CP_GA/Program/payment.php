<?php 

session_start();
include 'connection.php';
include 'autoid.php';

if (isset($_SESSION['s_id'])) 
{
	$staffid = $_SESSION['s_id'];


	$TotalAmount=0;
	$numberofDays =  0;


	$io_id = $_GET['ioid'];
	$query = "	SELECT c.*, res.*, r.*, rd.*, g.*, rt.* 
	 			FROM checkin c, reservation res, room r, roomtype rt, reservationdetail rd, guest g
	 			WHERE io_id = '$io_id'
	 			AND c.reservation_id = res.reservation_id
	 			AND res.reservation_id = rd.reservation_id
	 			AND res.guest_id = g.guest_id
	 			AND rd.room_id = r.room_id
	 			AND r.roomtype_id = rt.roomtype_id";

	$run = mysqli_query($connection, $query);
	$count = mysqli_num_rows($run);

	if ($count == 1) 
	{
		$array = mysqli_fetch_array($run);
		$io_id = $array['io_id'];
		$guest_id = $array['guest_id'];
		$guest_name = $array['guest_name'];
		$checkin = $array['checkin_date'];
		$checkout = $array['checkout_date'];
		$price = $array['roomtype_price']; 
		$room = $array['room_id'];

	}

		$out = strtotime($checkout);
		$in = strtotime($checkin);
	$diff = ($out - $in)/60/60/24;

	$TotalAmount = ($price + ($price*0.05)) * $diff;


/*

// Declare two dates
$start_date = strtotime("2018-06-08");
$end_date = strtotime("2018-09-19");
  
// Get the difference and divide into 
// total no. seconds 60/60/24 to get 
// number of days
echo "Difference between two dates: "
    . ($end_date - $start_date)/60/60/24;


*/





   
  }

  else
  {

  	echo "<script> window.alert('Error: Please log in again. ')</script>";
	echo "<script> window.location='stafflogin.php' </script>";

  }



 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<meta charset="utf-8">
 	<title> Payment </title>
 	<style type="text/css">

	

 	body
 	{

 		font-family: Arial;
 	}
 		#tbl
 		{ 
 			width: 80%;
 			padding: 30px;
 			
 		}

		table th
		{
			background-color: #D1D5DA;

		}
		tr
		{
			height: 50px;
		}


		a
		{
			text-decoration: none;
		}

		#back
		{
			font-size: 15px;
			color: black;
			padding: 12px;
			font-weight: bold;
			background-color: #BFC5E3;
		}


 	</style>

 </head>
 <body>

<?php 

$today = date('Y-m-d');

 ?>
 <form action="payment.php" method="POST ">
 	
 		<p>
 			<img src="temp_img/logo.jpg" height="120px" width="120px">

 		</p>
 		<table id="tbl" border="1px" align="center" style="border-collapse: collapse;">
 			<tr>
 				<th colspan="4"> Invoice </th>
 			</tr>
 			<tr>
 				<td colspan="4"> 
 				<p style="float: right;"> Date: <?php echo "$today"; ?></p>

 					<p> Guest ID: <?php echo $guest_id; ?></p> 				
 					<p> Guest Name: <?php echo "$guest_name";  ?></p>
 				</td>
 			</tr>
 			<tr>
 				<th> Room No.  </th>
 				<th> Price </th>
 				<th> Number of Days </th>
 				<th> Amount </th>
 			</tr>
 				<tr align="right">
	 			<td> <?php echo "$room"; ?></td>
	 			<td> <?php echo "$price"; ?></td>
	 			<td> <?php echo "$diff"; ?></td>
	 			<td> <?php echo $price * $diff ;
	 						$amount =  $price * $diff;  ?></td>
 			</tr>
 			<tr>
 			<td colspan="3" align="right"> VAT </td>
 			<td align="right"> <?php 	echo ($price * $diff)* 0.05 ; 
 					$tax = ($price * $diff)* 0.05;  ?>
 						
 			</td>
 		</tr>
 		<tr>
 			<td colspan="3" align="right"> Total </td>
 			<td align="right"><?php echo $TotalAmount; ?></td>
 		</tr>

 		</table>
 		<br><br>
 			Contact us: <br>
 			Email: happystay@email.com <br>
 			Phone: +9349365734 <br>
 			Line: happystay.rec <br>	
 			<br><br>

 		<?php 

		$pid = auto_id('payment','payment_id','P-',6); 
		$insert = "INSERT into payment values ('$pid', '$today', '$amount','$tax', '$staffid', '$io_id')";
		$run = mysqli_query ($connection, $insert);

 		 ?>


<br>
<a href="dashboard.php" id="back"> &#8592; Back </a>

 </form>
 </body>
 </html>