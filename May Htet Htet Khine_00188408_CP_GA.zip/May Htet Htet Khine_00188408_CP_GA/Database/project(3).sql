-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2021 at 07:17 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `checkin`
--

CREATE TABLE `checkin` (
  `io_id` varchar(10) NOT NULL,
  `guest_id` varchar(10) NOT NULL,
  `staff_id` varchar(10) NOT NULL,
  `checkin_date` date NOT NULL,
  `checkin_time` time NOT NULL,
  `reservation_id` varchar(10) DEFAULT NULL,
  `check_out` varchar(10) NOT NULL,
  `checkout_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `checkin`
--

INSERT INTO `checkin` (`io_id`, `guest_id`, `staff_id`, `checkin_date`, `checkin_time`, `reservation_id`, `check_out`, `checkout_date`) VALUES
('IO-000001', 'GT-000001', 'S-000001', '2021-09-28', '08:31:33', 'RV-000001', 'Yes', '2021-10-08'),
('IO-000002', 'GT-000001', 'S-000001', '2021-09-30', '09:04:05', 'RV-000002', 'Yes', '2021-10-08'),
('IO-000003', 'GT-000004', 'S-000001', '2021-10-01', '07:09:25', 'RV-000003', 'Yes', '2021-10-12'),
('IO-000004', 'GT-000004', 'S-000001', '2021-10-01', '07:09:44', 'RV-000003', 'Yes', '2021-10-01'),
('IO-000005', 'GT-000001', 'S-000001', '2021-10-03', '04:45:02', 'RV-000005', 'Yes', '2021-10-03'),
('IO-000006', 'GT-000002', 'S-000001', '2021-10-03', '06:49:10', 'RV-000004', 'Yes', '2021-10-07'),
('IO-000007', 'GT-000006', 'S-000001', '2021-10-07', '07:03:38', 'RV-000006', 'Yes', '2021-10-11'),
('IO-000008', 'GT-000001', 'S-000001', '2021-10-07', '07:03:41', 'RV-000008', 'No', NULL),
('IO-000009', 'GT-000003', 'S-000001', '2021-10-07', '07:03:44', 'RV-000007', 'No', NULL),
('IO-000010', 'GT-000007', 'S-000001', '2021-10-11', '07:03:14', 'RV-000009', 'No', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `guest`
--

CREATE TABLE `guest` (
  `guest_id` varchar(15) NOT NULL,
  `guest_name` varchar(50) NOT NULL,
  `guest_nrc` varchar(50) NOT NULL,
  `guest_phone` varchar(50) NOT NULL,
  `guest_status` varchar(30) NOT NULL,
  `staff_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `guest`
--

INSERT INTO `guest` (`guest_id`, `guest_name`, `guest_nrc`, `guest_phone`, `guest_status`, `staff_id`) VALUES
('GT-000001', 'Susan Pink', '12/LaDaNa(C)267364', '089437773', 'active', 'S-000002'),
('GT-000002', 'Jimmy Brown', '15/KaSaYa(C)237282', '073843299', 'active', 'S-000002'),
('GT-000003', 'Yenny Fu', '9/TaYaMa(C)343849', '068734283', 'active', 'S-000002'),
('GT-000004', 'Kamimoto Kotone', '12/33893(C)', '07364632', 'inactive', 'S-000001'),
('GT-000005', 'Ikema Ruan', '16/783249(C)', '073472648', 'active', 'S-000001'),
('GT-000006', 'Ezaki Hikaru', '11/372803(F)', '0137434833', 'active', 'S-000001'),
('GT-000007', 'Johnny Kim', '12(P)3482392', '0432934334', 'active', 'S-000004');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` varchar(15) NOT NULL,
  `payment_date` date NOT NULL,
  `payment_amount` int(11) NOT NULL,
  `tax` float NOT NULL,
  `staff_id` varchar(20) NOT NULL,
  `io_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `payment_date`, `payment_amount`, `tax`, `staff_id`, `io_id`) VALUES
('P-000001', '2021-09-28', 5000, 250, '0', 'IO-000001'),
('P-000002', '2021-09-28', 5000, 250, 'S-000001', 'IO-000001'),
('P-000003', '2021-09-28', 5000, 250, 'S-000001', 'IO-000001'),
('P-000004', '2021-09-30', 5000, 250, 'S-000001', 'IO-000001'),
('P-000005', '2021-09-30', 5000, 250, 'S-000001', 'IO-000001'),
('P-000006', '2021-09-30', 5000, 250, 'S-000001', 'IO-000001'),
('P-000007', '2021-09-30', 4000, 200, 'S-000001', 'IO-000002'),
('P-000008', '2021-10-01', 0, 0, 'S-000001', 'IO-000004'),
('P-000009', '2021-10-01', 5000, 250, 'S-000001', 'IO-000001'),
('P-000010', '2021-10-01', 5000, 250, 'S-000001', 'IO-000001'),
('P-000011', '2021-10-03', 5500, 275, 'S-000001', 'IO-000003'),
('P-000012', '2021-10-03', 0, 0, 'S-000001', 'IO-000005'),
('P-000013', '2021-10-03', 5000, 250, 'S-000001', 'IO-000001'),
('P-000014', '2021-10-03', 5000, 250, 'S-000001', 'IO-000001'),
('P-000015', '2021-10-07', 2000, 100, 'S-000001', 'IO-000006'),
('P-000016', '2021-10-11', 2800, 140, 'S-000001', 'IO-000007'),
('P-000017', '2021-10-11', 2000, 100, 'S-000001', 'IO-000006');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` varchar(15) NOT NULL,
  `reservation_status` varchar(50) NOT NULL,
  `reservation_date` date NOT NULL,
  `guest_id` varchar(15) NOT NULL,
  `checkindate` date NOT NULL,
  `checkoutdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `reservation_status`, `reservation_date`, `guest_id`, `checkindate`, `checkoutdate`) VALUES
('RV-000001', 'finished', '2021-09-28', 'GT-000001', '2021-09-02', '2021-09-15'),
('RV-000002', 'finished', '2021-09-30', 'GT-000001', '2021-10-02', '2021-10-12'),
('RV-000003', 'finished', '2021-09-30', 'GT-000004', '2021-10-04', '2021-10-20'),
('RV-000004', 'finished', '2021-10-03', 'GT-000002', '2021-10-14', '2021-10-26'),
('RV-000005', 'finished', '2021-10-03', 'GT-000001', '2021-10-03', '2021-10-05'),
('RV-000006', 'finished', '2021-10-03', 'GT-000006', '2021-10-05', '2021-10-13'),
('RV-000007', 'finished', '2021-10-03', 'GT-000003', '2021-10-15', '2021-10-18'),
('RV-000008', 'finished', '2021-10-03', 'GT-000001', '2021-10-03', '2021-10-08'),
('RV-000009', 'finished', '2021-10-11', 'GT-000007', '2021-10-11', '2021-10-17'),
('RV-000010', 'active', '2021-10-11', 'GT-000001', '2021-10-05', '2021-10-12'),
('RV-000011', 'active', '2021-10-11', 'GT-000003', '2021-10-16', '2021-10-18');

-- --------------------------------------------------------

--
-- Table structure for table `reservationdetail`
--

CREATE TABLE `reservationdetail` (
  `r_detail_id` varchar(20) NOT NULL,
  `reservation_id` varchar(15) NOT NULL,
  `room_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reservationdetail`
--

INSERT INTO `reservationdetail` (`r_detail_id`, `reservation_id`, `room_id`) VALUES
('RD-000001', 'RV-000001', '101'),
('RD-000002', 'RV-000002', '101'),
('RD-000003', 'RV-000003', '104'),
('RD-000004', 'RV-000004', '101'),
('RD-000005', 'RV-000005', '102'),
('RD-000006', 'RV-000006', '102'),
('RD-000007', 'RV-000007', '104'),
('RD-000008', 'RV-000008', '102'),
('RD-000009', 'RV-000009', '102'),
('RD-000010', 'RV-000010', '104'),
('RD-000011', 'RV-000011', '101');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `room_id` varchar(10) NOT NULL,
  `room_status` varchar(30) NOT NULL,
  `room_img` text NOT NULL,
  `room_img2` text NOT NULL,
  `roomtype_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`room_id`, `room_status`, `room_img`, `room_img2`, `roomtype_id`) VALUES
('101', 'Available', 'roomimg/_single.jpg', 'roomimg/_roomie.jpg', 'RT-000001'),
('102', 'Available', 'roomimg/_hotelroom.jpg', 'roomimg/_beach.jpg', 'RT-000003'),
('103', 'Out of order', 'roomimg/_room.jpg', 'roomimg/_roomie.jpg', 'RT-000003'),
('104', 'Available', 'roomimg/_hotelroom.jpg', 'roomimg/_room.jpg', 'RT-000001');

-- --------------------------------------------------------

--
-- Table structure for table `roomtype`
--

CREATE TABLE `roomtype` (
  `roomtype_id` varchar(15) NOT NULL,
  `roomtype_name` varchar(30) NOT NULL,
  `roomtype_price` int(11) NOT NULL,
  `roomtype_cleaning` varchar(30) NOT NULL,
  `roomtype_bed` int(11) NOT NULL,
  `roomtype_services` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roomtype`
--

INSERT INTO `roomtype` (`roomtype_id`, `roomtype_name`, `roomtype_price`, `roomtype_cleaning`, `roomtype_bed`, `roomtype_services`) VALUES
('RT-000001', 'Standard Single', 500, 'once_a_day', 1, 'Swimming Pool,Sea View,Breakfast'),
('RT-000002', 'Standard Double', 1000, 'once_a_day', 2, 'Swimming Pool,Airport Vehical,Sea View,Breakfast'),
('RT-000003', 'Premium Single', 700, 'twice_a_day', 1, 'Swimming Pool,Airport Vehical,Sea View,Breakfast,Lunch'),
('RT-000004', 'Premium Double', 1500, 'twice_a_day', 2, 'Swimming Pool,Spa,Airport Vehical,Sea View,Breakfast'),
('RT-000005', 'Premium Suite', 2200, 'twice_a_day', 4, 'Swimming Pool,Spa,Airport Vehical,Sea View,Breakfast'),
('RT-000006', 'Standard Suite', 2000, 'once_a_day', 4, ''),
('RT-000007', 'hhhhhhhhhh', 342, 'once_a_day', 3, '-'),
('RT-000008', 'jdkf', 300, 'once_a_day', 1, 'Swimming Pool'),
('RT-000009', 'ee', 3, 'once_a_day', 2, 'None');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` varchar(20) NOT NULL,
  `staff_name` varchar(50) NOT NULL,
  `staff_email` varchar(60) NOT NULL,
  `staff_password` varchar(50) NOT NULL,
  `staff_phone` varchar(50) NOT NULL,
  `staff_position` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `staff_name`, `staff_email`, `staff_password`, `staff_phone`, `staff_position`) VALUES
('S-000001', 'Nathan Soles', 'nathan55@gmail.com', 'nathan', '08373000', 'Data Analyst'),
('S-000002', 'Robert Junior', 'robert@email.com', 'robert', '0963387000', 'Receptionist'),
('S-000004', 'Joshua Hong', 'joshua@gmail.com', 'joshua', '0238232399', 'Receptionist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `checkin`
--
ALTER TABLE `checkin`
  ADD PRIMARY KEY (`io_id`);

--
-- Indexes for table `guest`
--
ALTER TABLE `guest`
  ADD PRIMARY KEY (`guest_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`reservation_id`);

--
-- Indexes for table `reservationdetail`
--
ALTER TABLE `reservationdetail`
  ADD PRIMARY KEY (`r_detail_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `roomtype`
--
ALTER TABLE `roomtype`
  ADD PRIMARY KEY (`roomtype_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
